prompt --application/shared_components/security/authentications/ad_authentication
begin
--   Manifest
--     AUTHENTICATION: AD Authentication
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_authentication(
 p_id=>wwv_flow_api.id(36352509394894395)
,p_name=>'AD Authentication'
,p_scheme_type=>'NATIVE_LDAP'
,p_attribute_01=>'ict.local'
,p_attribute_02=>'636'
,p_attribute_03=>'SSL_AUTH'
,p_attribute_04=>'ICT\%LDAP_USER%'
,p_attribute_05=>'Y'
,p_attribute_08=>'STD'
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_api.component_end;
end;
/
