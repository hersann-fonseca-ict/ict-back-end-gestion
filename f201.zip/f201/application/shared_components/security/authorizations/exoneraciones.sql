prompt --application/shared_components/security/authorizations/exoneraciones
begin
--   Manifest
--     SECURITY SCHEME: Exoneraciones
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_security_scheme(
 p_id=>wwv_flow_api.id(134932345166002785)
,p_name=>'Exoneraciones'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'permiso number(1);',
'begin',
'  select 1 ',
'     into permiso ',
'     from usuarios_gestion ',
'    where perfil = 13 ',
'      and usuario = ''mariela.urena@ict.go.cr'';',
'  if permiso = 1 then ',
'    return true; ',
'  else ',
'    return false; ',
'   end if;',
'exception',
'  when others then',
'  return false; ',
'end;',
'  ',
'',
''))
,p_error_message=>'No tiene permisos'
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_api.component_end;
end;
/
