prompt --application/shared_components/user_interface/lovs/lista_estados_ac_ia
begin
--   Manifest
--     LISTA_ESTADOS_AC_IA
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(182620877191192884)
,p_lov_name=>'LISTA_ESTADOS_AC_IA'
,p_lov_query=>'select nombre_estado, codigo_estado from estados_tramite@consulta_ictx where codigo_estado = ''AC'' or codigo_estado = ''IA'''
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'CODIGO_ESTADO'
,p_display_column_name=>'NOMBRE_ESTADO'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'NOMBRE_ESTADO'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
