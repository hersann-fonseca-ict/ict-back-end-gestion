prompt --application/shared_components/user_interface/lovs/lista_procesos
begin
--   Manifest
--     LISTA_PROCESOS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(140410318601782588)
,p_lov_name=>'LISTA_PROCESOS'
,p_lov_query=>'select descripcion_estado, id_estado from estados_tramites'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID_ESTADO'
,p_display_column_name=>'DESCRIPCION_ESTADO'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'DESCRIPCION_ESTADO'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
