prompt --application/shared_components/user_interface/lovs/lista_todas_empresas
begin
--   Manifest
--     LISTA_TODAS_EMPRESAS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(259423403208025367)
,p_lov_name=>'LISTA_TODAS_EMPRESAS'
,p_lov_query=>'SELECT id_empresa, id_empresa || ''-'' || nombre_comercial AS nombre_comercial FROM empresa;'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_query_table=>'EMPRESA'
,p_return_column_name=>'ID_EMPRESA'
,p_display_column_name=>'NOMBRE_COMERCIAL'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'NOMBRE_COMERCIAL'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
