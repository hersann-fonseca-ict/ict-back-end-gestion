prompt --application/shared_components/user_interface/lovs/lista_operacion
begin
--   Manifest
--     LISTA_OPERACION
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(39624421094645434)
,p_lov_name=>'LISTA_OPERACION'
,p_lov_query=>'.'||wwv_flow_api.id(39624421094645434)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(39624713432645435)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('En Operaci\00F3n')
,p_lov_return_value=>'1'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(39625186399645438)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'En Proyecto'
,p_lov_return_value=>'2'
);
wwv_flow_api.component_end;
end;
/
