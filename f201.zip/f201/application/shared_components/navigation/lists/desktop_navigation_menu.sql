prompt --application/shared_components/navigation/lists/desktop_navigation_menu
begin
--   Manifest
--     LIST: Desktop Navigation Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(36353279942894395)
,p_name=>'Desktop Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(36501492250894325)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'Inicio'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(259028248571314927)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Bit\00E1coras')
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT perfiles.bitacoras',
'FROM USUARIOS_GESTION',
'INNER JOIN PERFILES ON USUARIOS_GESTION.PERFIL = PERFILES.ID_PERFIL WHERE UPPER(USUARIO) = :APP_USER AND perfiles.bitacoras = ''Y'';'))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(259028818691334637)
,p_list_item_display_sequence=>360
,p_list_item_link_text=>unistr('Par\00E1metros')
,p_parent_list_item_id=>wwv_flow_api.id(259028248571314927)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(259029277787345443)
,p_list_item_display_sequence=>370
,p_list_item_link_text=>'Usuarios'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(259028818691334637)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'24'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(259068299280605093)
,p_list_item_display_sequence=>380
,p_list_item_link_text=>'Perfiles'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(259028818691334637)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'25'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(259103289617743887)
,p_list_item_display_sequence=>390
,p_list_item_link_text=>unistr('Declaratoria Tur\00EDstica')
,p_parent_list_item_id=>wwv_flow_api.id(259028818691334637)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(259103702745763872)
,p_list_item_display_sequence=>400
,p_list_item_link_text=>'Tipos'
,p_list_item_link_target=>'f?p=&APP_ID.:26:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(259103289617743887)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'26'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(259126792489934830)
,p_list_item_display_sequence=>410
,p_list_item_link_text=>unistr('Categor\00EDas')
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:27:::'
,p_parent_list_item_id=>wwv_flow_api.id(259103289617743887)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'27'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(259151385587734521)
,p_list_item_display_sequence=>420
,p_list_item_link_text=>'Procesos'
,p_parent_list_item_id=>wwv_flow_api.id(259028248571314927)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(259245702339448096)
,p_list_item_display_sequence=>420
,p_list_item_link_text=>'Logueos al Sistema'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(259151385587734521)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'30'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(259151771961748195)
,p_list_item_display_sequence=>430
,p_list_item_link_text=>'Empresas'
,p_list_item_link_target=>'f?p=&APP_ID.:28:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(259151385587734521)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'28'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(259376517239502535)
,p_list_item_display_sequence=>460
,p_list_item_link_text=>unistr('Declaraciones & Contratos Tur\00EDsticos')
,p_parent_list_item_id=>wwv_flow_api.id(259151385587734521)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(259420287314952662)
,p_list_item_display_sequence=>470
,p_list_item_link_text=>'Historial de Registros'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:31:::'
,p_parent_list_item_id=>wwv_flow_api.id(259376517239502535)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(14555819037719757)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>unistr('Par\00E1metros')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(36532836173829666)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Usuarios'
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT perfiles.parametros_usuarios',
'FROM USUARIOS_GESTION',
'INNER JOIN PERFILES ON USUARIOS_GESTION.PERFIL = PERFILES.ID_PERFIL WHERE UPPER(USUARIO) = :APP_USER AND perfiles.parametros_usuarios = ''Y'';'))
,p_parent_list_item_id=>wwv_flow_api.id(14555819037719757)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'200,4'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(14657470616622689)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Perfiles'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT perfiles.parametros_perfiles',
'FROM USUARIOS_GESTION',
'INNER JOIN PERFILES ON USUARIOS_GESTION.PERFIL = PERFILES.ID_PERFIL WHERE UPPER(USUARIO) = :APP_USER AND perfiles.parametros_perfiles = ''Y'';'))
,p_parent_list_item_id=>wwv_flow_api.id(14555819037719757)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'103,104'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(15466860049659703)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>unistr('Declaratoria Tur\00EDstica')
,p_list_item_link_target=>'f?p=&APP_ID.:0:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT perfiles.parametros_dt',
'FROM USUARIOS_GESTION',
'INNER JOIN PERFILES ON USUARIOS_GESTION.PERFIL = PERFILES.ID_PERFIL WHERE UPPER(USUARIO) = :APP_USER AND perfiles.parametros_dt = ''Y'';'))
,p_parent_list_item_id=>wwv_flow_api.id(14555819037719757)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(14565129980709129)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Tipos'
,p_list_item_link_target=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(15466860049659703)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'101,102'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(15476513006620193)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>unistr('Categor\00EDas de Hospedajes')
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(15466860049659703)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6,8'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(15613549448077458)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>unistr('Categor\00EDas Gastron\00F3micas')
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(15466860049659703)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'9,10'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(15744494271079979)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>unistr('Actividades Tem\00E1ticas')
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(15466860049659703)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'17,18'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(15757037645058601)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>unistr('Transportes Acu\00E1ticos')
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(15466860049659703)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'19,20'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(12255871378014215)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Pendientes'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(254937557898173090)
,p_list_item_display_sequence=>330
,p_list_item_link_text=>unistr('Declaraciones Tur\00EDsticas')
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT perfiles.pendientes_dt',
'FROM USUARIOS_GESTION',
'INNER JOIN PERFILES ON USUARIOS_GESTION.PERFIL = PERFILES.ID_PERFIL WHERE UPPER(USUARIO) = :APP_USER AND perfiles.pendientes_dt = ''Y'';'))
,p_parent_list_item_id=>wwv_flow_api.id(12255871378014215)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(255083800723182643)
,p_list_item_display_sequence=>340
,p_list_item_link_text=>unistr('Contratos Tur\00EDsticos')
,p_list_item_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT perfiles.pendientes_ct',
'FROM USUARIOS_GESTION',
'INNER JOIN PERFILES ON USUARIOS_GESTION.PERFIL = PERFILES.ID_PERFIL WHERE UPPER(USUARIO) = :APP_USER AND perfiles.pendientes_ct = ''Y'';'))
,p_parent_list_item_id=>wwv_flow_api.id(12255871378014215)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'23'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(36514260778843423)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Reportes'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'100,5,7,201,210,300,301,302,301,301'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(44689902536660228)
,p_list_item_display_sequence=>290
,p_list_item_link_text=>unistr('Declararaciones Tur\00EDsticas')
,p_list_item_link_target=>'f?p=&APP_ID.:302:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT perfiles.reportes_dt',
'FROM USUARIOS_GESTION',
'INNER JOIN PERFILES ON USUARIOS_GESTION.PERFIL = PERFILES.ID_PERFIL WHERE UPPER(USUARIO) = :APP_USER AND perfiles.reportes_dt = ''Y'';'))
,p_parent_list_item_id=>wwv_flow_api.id(36514260778843423)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'302'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(106436487945298120)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>unistr('Contratos Tur\00EDsticos')
,p_list_item_link_target=>'f?p=&APP_ID.:301:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT perfiles.reportes_ct',
'FROM USUARIOS_GESTION',
'INNER JOIN PERFILES ON USUARIOS_GESTION.PERFIL = PERFILES.ID_PERFIL WHERE UPPER(USUARIO) = :APP_USER AND perfiles.reportes_ct = ''Y'';'))
,p_parent_list_item_id=>wwv_flow_api.id(36514260778843423)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'301'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(36194464138358420)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'Mis expedientes'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(252379423518468005)
,p_list_item_display_sequence=>310
,p_list_item_link_text=>unistr('An\00E1lisis de Declaraciones Tur\00EDsticas')
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT perfiles.expedientes_dt',
'FROM USUARIOS_GESTION',
'INNER JOIN PERFILES ON USUARIOS_GESTION.PERFIL = PERFILES.ID_PERFIL WHERE UPPER(USUARIO) = :APP_USER AND perfiles.expedientes_dt = ''Y'';'))
,p_parent_list_item_id=>wwv_flow_api.id(36194464138358420)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'202,203'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(253181020033645613)
,p_list_item_display_sequence=>320
,p_list_item_link_text=>unistr('An\00E1lisis de Contratos Tur\00EDsticos')
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT perfiles.expedientes_ct',
'FROM USUARIOS_GESTION',
'INNER JOIN PERFILES ON USUARIOS_GESTION.PERFIL = PERFILES.ID_PERFIL WHERE UPPER(USUARIO) = :APP_USER AND perfiles.expedientes_ct = ''Y'';'))
,p_parent_list_item_id=>wwv_flow_api.id(36194464138358420)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'204,205'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(38158378809067785)
,p_list_item_display_sequence=>240
,p_list_item_link_text=>'Seguimientos'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(38187102260310403)
,p_list_item_display_sequence=>250
,p_list_item_link_text=>unistr('Declaraciones Tur\00EDsticas')
,p_list_item_link_target=>'f?p=&APP_ID.:206:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT perfiles.seguimientos_dt',
'FROM USUARIOS_GESTION',
'INNER JOIN PERFILES ON USUARIOS_GESTION.PERFIL = PERFILES.ID_PERFIL WHERE UPPER(USUARIO) = :APP_USER AND perfiles.seguimientos_dt = ''Y'';'))
,p_parent_list_item_id=>wwv_flow_api.id(38158378809067785)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'206,207'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40063711923692312)
,p_list_item_display_sequence=>260
,p_list_item_link_text=>unistr('Contratos Tur\00EDsticos')
,p_list_item_link_target=>'f?p=&APP_ID.:208:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT perfiles.seguimientos_ct',
'FROM USUARIOS_GESTION',
'INNER JOIN PERFILES ON USUARIOS_GESTION.PERFIL = PERFILES.ID_PERFIL WHERE UPPER(USUARIO) = :APP_USER AND perfiles.seguimientos_ct = ''Y'';'))
,p_parent_list_item_id=>wwv_flow_api.id(38158378809067785)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'208,209'
);
wwv_flow_api.component_end;
end;
/
