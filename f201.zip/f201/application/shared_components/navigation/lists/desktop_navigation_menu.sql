prompt --application/shared_components/navigation/lists/desktop_navigation_menu
begin
--   Manifest
--     LIST: Desktop Navigation Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(36353279942894395)
,p_name=>'Desktop Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(36501492250894325)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Inicio'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(14555819037719757)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>unistr('Par\00E1metros')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(36532836173829666)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Usuarios'
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(14555819037719757)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'200,4'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(14657470616622689)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Perfiles'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(14555819037719757)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'103,104'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(15466860049659703)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>unistr('Declaratoria Tur\00EDstica')
,p_list_item_link_target=>'f?p=&APP_ID.:0:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(14555819037719757)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(14565129980709129)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Tipos'
,p_list_item_link_target=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(15466860049659703)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'101,102'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(15476513006620193)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>unistr('Categor\00EDas de Hospedajes')
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(15466860049659703)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6,8'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(15613549448077458)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>unistr('Categor\00EDas Gastron\00F3micas')
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(15466860049659703)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'9,10'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(15744494271079979)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>unistr('Actividades Tem\00E1ticas')
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(15466860049659703)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'17,18'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(15757037645058601)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>unistr('Transportes Acu\00E1ticos')
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(15466860049659703)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'19,20'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(12255871378014215)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Pendientes'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(12257052828000944)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>unistr('Declaratoria Tur\00EDstica')
,p_list_item_link_target=>'f?p=&APP_ID.:2000:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(12255871378014215)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(12257742612996844)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>unistr('Contrato Tur\00EDstico')
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(12255871378014215)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(36514260778843423)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Reportes'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'100,5,7,201,210,300,301,302,301,301'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(44689902536660228)
,p_list_item_display_sequence=>290
,p_list_item_link_text=>unistr('Declaratoria Tur\00EDstica')
,p_list_item_link_target=>'f?p=&APP_ID.:302:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(36514260778843423)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'302'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(106436487945298120)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>unistr('Contrato Tur\00EDstico')
,p_list_item_link_target=>'f?p=&APP_ID.:301:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(36514260778843423)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'301'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(36194464138358420)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'Mis expedientes'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(252379423518468005)
,p_list_item_display_sequence=>310
,p_list_item_link_text=>unistr('An\00E1lisis de Declaraciones Tur\00EDsticas')
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(36194464138358420)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'202,203'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(253181020033645613)
,p_list_item_display_sequence=>320
,p_list_item_link_text=>unistr('An\00E1lisis de Contratos Tur\00EDsticos')
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(36194464138358420)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'204,205'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(38158378809067785)
,p_list_item_display_sequence=>240
,p_list_item_link_text=>'Seguimientos'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(38187102260310403)
,p_list_item_display_sequence=>250
,p_list_item_link_text=>unistr('Declaraciones Tur\00EDsticas')
,p_list_item_link_target=>'f?p=&APP_ID.:206:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(38158378809067785)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'206,207'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40063711923692312)
,p_list_item_display_sequence=>260
,p_list_item_link_text=>unistr('Contratos Tur\00EDsticos')
,p_list_item_link_target=>'f?p=&APP_ID.:208:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(38158378809067785)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'208,209'
);
wwv_flow_api.component_end;
end;
/
