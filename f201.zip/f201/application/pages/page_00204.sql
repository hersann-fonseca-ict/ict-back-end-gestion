prompt --application/pages/page_00204
begin
--   Manifest
--     PAGE: 00204
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>204
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>'Legacy: ReporteCT_Anotaciones'
,p_alias=>'REPORTECT-ANOTACIONES-LEGACY'
,p_step_title=>'ReporteCT_Anotaciones'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20240925145032'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(37815396933102267)
,p_name=>unistr('An\00E1lisis de los Contractos Tur\00EDsticos')
,p_template=>wwv_flow_api.id(36406847262894371)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  empresa.id_empresa , empresa.nombre_solicitante,  empresa.tipo_cedula,empresa.cedula, ',
'  empresa.nacional, empresa.razon_social, empresa.nombre_comercial,',
' empresa.telefono, empresa.correo ,empresa.id_provincia, empresa.id_canton, empresa.id_distrito, empresa.direccion_exacta,',
'',
' declaratoria_turistica.id_declaratoria , declaratoria_turistica.cantidad_colaboradores ,',
' declaratoria_turistica.moneda, declaratoria_turistica.monto_inversion, ',
' ',
'   operacion_dt.id_operacion_dt, operacion_dt.si_operacion, --operacion_dt.permiso_salud, operacion_dt.cronograma, operacion_dt.patente_municipal,',
' sys.dbms_lob.getlength(operacion_dt.permiso_salud) Permiso_Salud,',
' sys.dbms_lob.getlength(operacion_dt.cronograma) Cronograma,',
' sys.dbms_lob.getlength(operacion_dt.patente_municipal) Patente,',
' operacion_dt.tarchivo_permiso, operacion_dt.tarchivo_cronograma,',
' operacion_dt.tarchivo_patente,',
'  ',
'  contrato_turistico.id_contrato , contrato_turistico.fecha_registro, ',
'  contrato_turistico.fecha_caducidad, contrato_turistico.estudio_economico, contrato_turistico.planos_const,',
'  contrato_turistico.tarchivo_estudio, contrato_turistico.tarchivo_planos, contrato_turistico.estadoct ,',
'  contrato_turistico.plan_compras, contrato_turistico.tarchivo_pcompras',
'',
'FROM empresa',
'   JOIN declaratoria_turistica ON empresa.id_empresa = declaratoria_turistica.id_empresa ',
'    ',
'   left JOIN operacion_dt ON operacion_dt.id_declaratoria = declaratoria_turistica.id_declaratoria ',
' ',
' left JOIN contrato_turistico ON contrato_turistico.ID_DECLARATORIA = declaratoria_turistica.id_declaratoria',
'',
' WHERE contrato_turistico.id_analista = PKG_USUARIOS.Consulta_usuario(:APP_USER)',
'     or contrato_turistico.ID_INSPECTOR = PKG_USUARIOS.Consulta_usuario(:APP_USER)',
'  ',
'       ',
'--WHERE contrato_turistico.ID_ANALISTA IS NOT NULL '))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37815764717102271)
,p_query_column_id=>1
,p_column_alias=>'ID_EMPRESA'
,p_column_display_sequence=>1
,p_column_heading=>'Ver Detalles'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:205:&SESSION.::&DEBUG.:RP,:P205_ID_EMPRESA:#ID_EMPRESA#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37816136048102272)
,p_query_column_id=>2
,p_column_alias=>'NOMBRE_SOLICITANTE'
,p_column_display_sequence=>4
,p_column_heading=>'Nombre Solicitante'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37816586977102273)
,p_query_column_id=>3
,p_column_alias=>'TIPO_CEDULA'
,p_column_display_sequence=>5
,p_column_heading=>unistr('Tipo C\00E9dula')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37816904769102273)
,p_query_column_id=>4
,p_column_alias=>'CEDULA'
,p_column_display_sequence=>6
,p_column_heading=>unistr('C\00E9dula')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37817345237102273)
,p_query_column_id=>5
,p_column_alias=>'NACIONAL'
,p_column_display_sequence=>7
,p_column_heading=>'Nacional'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37817786783102273)
,p_query_column_id=>6
,p_column_alias=>'RAZON_SOCIAL'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37818138337102274)
,p_query_column_id=>7
,p_column_alias=>'NOMBRE_COMERCIAL'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37818509863102274)
,p_query_column_id=>8
,p_column_alias=>'TELEFONO'
,p_column_display_sequence=>10
,p_column_heading=>unistr('Tel\00E9fono')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37818980126102274)
,p_query_column_id=>9
,p_column_alias=>'CORREO'
,p_column_display_sequence=>11
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37819375931102274)
,p_query_column_id=>10
,p_column_alias=>'ID_PROVINCIA'
,p_column_display_sequence=>12
,p_column_heading=>'Provincia'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(19980461641459915)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37819705966102275)
,p_query_column_id=>11
,p_column_alias=>'ID_CANTON'
,p_column_display_sequence=>13
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37820102730102275)
,p_query_column_id=>12
,p_column_alias=>'ID_DISTRITO'
,p_column_display_sequence=>14
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37820594184102275)
,p_query_column_id=>13
,p_column_alias=>'DIRECCION_EXACTA'
,p_column_display_sequence=>15
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37820980243102276)
,p_query_column_id=>14
,p_column_alias=>'ID_DECLARATORIA'
,p_column_display_sequence=>2
,p_column_heading=>'Id Declaratoria'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37821395644102276)
,p_query_column_id=>15
,p_column_alias=>'CANTIDAD_COLABORADORES'
,p_column_display_sequence=>16
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37821725859102276)
,p_query_column_id=>16
,p_column_alias=>'MONEDA'
,p_column_display_sequence=>17
,p_column_heading=>'Moneda'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37822136230102276)
,p_query_column_id=>17
,p_column_alias=>'MONTO_INVERSION'
,p_column_display_sequence=>18
,p_column_heading=>unistr('Monto Inversi\00F3n')
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37822588153102277)
,p_query_column_id=>18
,p_column_alias=>'ID_OPERACION_DT'
,p_column_display_sequence=>19
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37822997663102277)
,p_query_column_id=>19
,p_column_alias=>'SI_OPERACION'
,p_column_display_sequence=>20
,p_column_heading=>unistr('En Operaci\00F3n')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(39624421094645434)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37823319943102278)
,p_query_column_id=>20
,p_column_alias=>'PERMISO_SALUD'
,p_column_display_sequence=>21
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37823794526102278)
,p_query_column_id=>21
,p_column_alias=>'CRONOGRAMA'
,p_column_display_sequence=>22
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39640985746928514)
,p_query_column_id=>22
,p_column_alias=>'PATENTE'
,p_column_display_sequence=>35
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37824598806102278)
,p_query_column_id=>23
,p_column_alias=>'TARCHIVO_PERMISO'
,p_column_display_sequence=>23
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37824947254102279)
,p_query_column_id=>24
,p_column_alias=>'TARCHIVO_CRONOGRAMA'
,p_column_display_sequence=>24
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37825338264102279)
,p_query_column_id=>25
,p_column_alias=>'TARCHIVO_PATENTE'
,p_column_display_sequence=>25
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37830590127102285)
,p_query_column_id=>26
,p_column_alias=>'ID_CONTRATO'
,p_column_display_sequence=>3
,p_column_heading=>'Id Contrato'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37830917808102285)
,p_query_column_id=>27
,p_column_alias=>'FECHA_REGISTRO'
,p_column_display_sequence=>26
,p_column_heading=>'Fecha Registro Contrato'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37831331359102285)
,p_query_column_id=>28
,p_column_alias=>'FECHA_CADUCIDAD'
,p_column_display_sequence=>27
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37831756477102286)
,p_query_column_id=>29
,p_column_alias=>'ESTUDIO_ECONOMICO'
,p_column_display_sequence=>28
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37832184271102286)
,p_query_column_id=>30
,p_column_alias=>'PLANOS_CONST'
,p_column_display_sequence=>29
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37832595928102287)
,p_query_column_id=>31
,p_column_alias=>'TARCHIVO_ESTUDIO'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37832965932102287)
,p_query_column_id=>32
,p_column_alias=>'TARCHIVO_PLANOS'
,p_column_display_sequence=>31
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37833310033102287)
,p_query_column_id=>33
,p_column_alias=>'ESTADOCT'
,p_column_display_sequence=>32
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37833720093102288)
,p_query_column_id=>34
,p_column_alias=>'PLAN_COMPRAS'
,p_column_display_sequence=>33
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(37834166826102288)
,p_query_column_id=>35
,p_column_alias=>'TARCHIVO_PCOMPRAS'
,p_column_display_sequence=>34
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2584103007792604313)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36406847262894371)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Listado de los Contratos Tur\00EDsticos por revisar</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(37835350043102304)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(37815396933102267)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(36468943774894349)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:205:&SESSION.::&DEBUG.:205'
,p_button_condition_type=>'NEVER'
);
wwv_flow_api.component_end;
end;
/
