prompt --application/pages/page_00206
begin
--   Manifest
--     PAGE: 00206
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>206
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>'Seguimiento Declaraciones'
,p_alias=>'SEGUIMIENTO-DECLARACIONES'
,p_step_title=>'Seguimiento Declaraciones'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ADRIANA.RUBIO'
,p_last_upd_yyyymmddhh24miss=>'20230929121804'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(38178367572310390)
,p_plug_name=>unistr('Seguimiento a las Declaraciones Tur\00EDsticas')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(36404937346894372)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT empresa.id_empresa , empresa.nombre_solicitante, empresa.razon_social, empresa.nombre_comercial,',
' empresa.telefono, empresa.correo ,empresa.id_provincia, ',
'',
'--  (SELECT tipo_declaratoria.nombre_tipodt FROM tipo_declaratoria WHERE tipo_declaratoria.id_tipodt = tdt_solicitud.id_tipodt) as "Tipo",',
'  ',
' declaratoria_turistica.id_declaratoria , declaratoria_turistica.fecha_registro, declaratoria_turistica.id_analista, declaratoria_turistica.fecha_asig_analista,',
' declaratoria_turistica.id_inspector, declaratoria_turistica.fecha_asig_inspector, declaratoria_turistica.estadodt',
' ',
' --anotaciones.fecha_oficio, anotaciones.num_oficio, anotaciones.oficio, anotaciones.tarchivo_oficio, anotaciones.usuario_envia',
'',
'FROM empresa',
'   JOIN declaratoria_turistica ON empresa.id_empresa = declaratoria_turistica.id_empresa ',
'    ',
' -- left JOIN ANOTACIONES ON ANOTACIONES.id_declaratoria = declaratoria_turistica.id_declaratoria',
' ',
'--  JOIN tdt_solicitud ON tdt_solicitud.id_declaratoria = declaratoria_turistica.id_declaratoria',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Seguimiento a las Declaraciones Tur\00EDsticas')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(38199759647358101)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ADRIANA.RUBIO'
,p_internal_uid=>38199759647358101
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38199809453358102)
,p_db_column_name=>'ID_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Ver detalles'
,p_column_link=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.::P207_ID_EMPRESA:#ID_EMPRESA#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38200634350358110)
,p_db_column_name=>'ID_DECLARATORIA'
,p_display_order=>20
,p_column_identifier=>'I'
,p_column_label=>'Id Declaratoria'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38199952098358103)
,p_db_column_name=>'NOMBRE_SOLICITANTE'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Nombre Solicitante'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38200039018358104)
,p_db_column_name=>'RAZON_SOCIAL'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Razon Social'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38200103709358105)
,p_db_column_name=>'NOMBRE_COMERCIAL'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Nombre Comercial'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38200270139358106)
,p_db_column_name=>'TELEFONO'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Telefono'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38200328563358107)
,p_db_column_name=>'CORREO'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38200409477358108)
,p_db_column_name=>'ID_PROVINCIA'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Provincia'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_api.id(19980461641459915)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38200760532358111)
,p_db_column_name=>'FECHA_REGISTRO'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>'Fecha Registro de Solicitud'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38200886460358112)
,p_db_column_name=>'ID_ANALISTA'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'Analista'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_api.id(38604833692717378)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38200934913358113)
,p_db_column_name=>'FECHA_ASIG_ANALISTA'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>'Fecha Asig Analista'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38201060241358114)
,p_db_column_name=>'ID_INSPECTOR'
,p_display_order=>120
,p_column_identifier=>'M'
,p_column_label=>'Inspector'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_api.id(38604833692717378)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38201213667358116)
,p_db_column_name=>'ESTADODT'
,p_display_order=>130
,p_column_identifier=>'O'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_api.id(161672685883171523)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38478325672951110)
,p_db_column_name=>'FECHA_ASIG_INSPECTOR'
,p_display_order=>140
,p_column_identifier=>'P'
,p_column_label=>'Fecha Asig Inspector'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(38217435967358617)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'382175'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_EMPRESA:ID_DECLARATORIA:NOMBRE_SOLICITANTE:NOMBRE_COMERCIAL:ID_PROVINCIA:FECHA_REGISTRO:ID_ANALISTA:ID_INSPECTOR:ESTADODT:'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2785202549493005604)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36406847262894371)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Seguimiento Declaraciones Tur\00EDsticas</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(38187840392310405)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(38178367572310390)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(38188352026310405)
,p_event_id=>wwv_flow_api.id(38187840392310405)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(38178367572310390)
);
wwv_flow_api.component_end;
end;
/
