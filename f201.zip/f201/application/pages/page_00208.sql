prompt --application/pages/page_00208
begin
--   Manifest
--     PAGE: 00208
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>208
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>'Seguimiento Contratos'
,p_alias=>'SEGUIMIENTO-CONTRATOS'
,p_step_title=>'Seguimiento Contratos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ADRIANA.RUBIO'
,p_last_upd_yyyymmddhh24miss=>'20230929121920'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40054922180692297)
,p_plug_name=>unistr('Seguimiento a los Contratos Tur\00EDsticos')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(36404937346894372)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT empresa.id_empresa , empresa.nombre_solicitante, empresa.razon_social, empresa.nombre_comercial,',
' empresa.telefono, empresa.correo ,empresa.id_provincia, ',
'',
' declaratoria_turistica.id_declaratoria , declaratoria_turistica.fecha_registro as "FechaDT",',
' declaratoria_turistica.id_analista as "AnalistaDT", declaratoria_turistica.fecha_asig_analista as "FAnalistaDT",',
' declaratoria_turistica.id_inspector as "InspectorDT", declaratoria_turistica.fecha_asig_inspector as "FInspectorDT", ',
' declaratoria_turistica.estadodt,',
'',
'contrato_turistico.id_contrato , contrato_turistico.fecha_registro, ',
'  contrato_turistico.id_analista, contrato_turistico.fecha_asig_analista, contrato_turistico.id_inspector,',
'  contrato_turistico.fecha_asig_inspector, contrato_turistico.estadoct',
'',
'FROM empresa',
'   JOIN declaratoria_turistica ON empresa.id_empresa = declaratoria_turistica.id_empresa',
'   ',
'   JOIN contrato_turistico ON contrato_turistico.ID_DECLARATORIA = declaratoria_turistica.id_declaratoria'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Seguimiento a los Contratos Tur\00EDsticos')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(39641157029928516)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ADRIANA.RUBIO'
,p_internal_uid=>39641157029928516
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39641203595928517)
,p_db_column_name=>'ID_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Ver detalles'
,p_column_link=>'f?p=&APP_ID.:209:&SESSION.::&DEBUG.::P209_ID_EMPRESA:#ID_EMPRESA#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39641946479928524)
,p_db_column_name=>'ID_DECLARATORIA'
,p_display_order=>20
,p_column_identifier=>'H'
,p_column_label=>'Id Declaratoria'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39642615454928531)
,p_db_column_name=>'ID_CONTRATO'
,p_display_order=>30
,p_column_identifier=>'O'
,p_column_label=>'Id Contrato'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39641392025928518)
,p_db_column_name=>'NOMBRE_SOLICITANTE'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Nombre Solicitante'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39641422418928519)
,p_db_column_name=>'RAZON_SOCIAL'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Razon Social'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39641533626928520)
,p_db_column_name=>'NOMBRE_COMERCIAL'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Nombre Comercial'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39641617563928521)
,p_db_column_name=>'TELEFONO'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Telefono'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39641718265928522)
,p_db_column_name=>'CORREO'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39641806577928523)
,p_db_column_name=>'ID_PROVINCIA'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Provincia'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_api.id(19980461641459915)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39642011526928525)
,p_db_column_name=>'FechaDT'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Fechadt'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39642170927928526)
,p_db_column_name=>'AnalistaDT'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Analistadt'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39642245644928527)
,p_db_column_name=>'FAnalistaDT'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Fanalistadt'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39642320572928528)
,p_db_column_name=>'InspectorDT'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Inspectordt'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39642466048928529)
,p_db_column_name=>'FInspectorDT'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'Finspectordt'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39642579741928530)
,p_db_column_name=>'ESTADODT'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'Estadodt'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39642727018928532)
,p_db_column_name=>'FECHA_REGISTRO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Fecha Registro'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39642892558928533)
,p_db_column_name=>'ID_ANALISTA'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Analista'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_api.id(38604833692717378)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39642925516928534)
,p_db_column_name=>'FECHA_ASIG_ANALISTA'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Fecha Asig Analista'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39643001771928535)
,p_db_column_name=>'ID_INSPECTOR'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Inspector'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_api.id(38604833692717378)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39643170508928536)
,p_db_column_name=>'FECHA_ASIG_INSPECTOR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Fecha Asig Inspector'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39643264318928537)
,p_db_column_name=>'ESTADOCT'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_api.id(161672685883171523)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(40090644345763379)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'400907'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_EMPRESA:ID_DECLARATORIA:ID_CONTRATO:NOMBRE_SOLICITANTE:NOMBRE_COMERCIAL:ID_PROVINCIA:FECHA_REGISTRO:ID_ANALISTA:ID_INSPECTOR:ESTADOCT:'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2986303563718432697)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36406847262894371)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Seguimiento Contratos Tur\00EDsticos</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(40065490187692318)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(40054922180692297)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(36468943774894349)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:209:&SESSION.::&DEBUG.:209'
,p_button_condition_type=>'NEVER'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(40064482184692317)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(40054922180692297)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(40064919999692318)
,p_event_id=>wwv_flow_api.id(40064482184692317)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(40054922180692297)
);
wwv_flow_api.component_end;
end;
/
