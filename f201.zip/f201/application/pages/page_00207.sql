prompt --application/pages/page_00207
begin
--   Manifest
--     PAGE: 00207
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>207
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>unistr('Modal: Seguimiento de Declaraciones Tur\00EDsticas')
,p_alias=>'MODAL-SEGUIMIENTO-DECLA-TURI'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Seguimiento de Declaraciones Tur\00EDsticas')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20240924130014'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(38158701472310344)
,p_plug_name=>'Formulario Seguimiento Declaraciones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(36379437477894382)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT empresa.id_empresa , empresa.nombre_solicitante, empresa.razon_social, empresa.nombre_comercial,',
' empresa.telefono, empresa.correo ,empresa.id_provincia, ',
'',
' -- (SELECT tipo_declaratoria.nombre_tipodt FROM tipo_declaratoria WHERE tipo_declaratoria.id_tipodt = tdt_solicitud.id_tipodt) as "Tipo",',
'  ',
' declaratoria_turistica.id_declaratoria , declaratoria_turistica.fecha_registro, declaratoria_turistica.id_analista, declaratoria_turistica.fecha_asig_analista,',
' declaratoria_turistica.id_inspector, declaratoria_turistica.fecha_asig_inspector, declaratoria_turistica.estadodt',
' ',
'-- anotaciones.fecha_oficio, anotaciones.num_oficio, anotaciones.oficio, anotaciones.tarchivo_oficio, anotaciones.usuario_envia',
'',
'FROM empresa',
'   JOIN declaratoria_turistica ON empresa.id_empresa = declaratoria_turistica.id_empresa ',
'    ',
'--  left JOIN ANOTACIONES ON ANOTACIONES.id_declaratoria = declaratoria_turistica.id_declaratoria',
' ',
'--  JOIN tdt_solicitud ON tdt_solicitud.id_declaratoria = declaratoria_turistica.id_declaratoria',
''))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_read_only_when_type=>'ALWAYS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(38201817475358122)
,p_plug_name=>'Datos de la Empresa'
,p_parent_plug_id=>wwv_flow_api.id(38158701472310344)
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent3:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36389817495894378)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_read_only_when_type=>'ALWAYS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(38201948161358123)
,p_plug_name=>unistr('Datos de la Declaratoria Tur\00EDstica')
,p_parent_plug_id=>wwv_flow_api.id(38158701472310344)
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent5:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36389817495894378)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_read_only_when_type=>'ALWAYS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(38204482579358148)
,p_name=>unistr('Tipos de Declaratoria Tur\00EDstica')
,p_parent_plug_id=>wwv_flow_api.id(38201948161358123)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent4:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT b.nombre_tipodt FROM tdt_solicitud a, tipo_declaratoria b ',
'WHERE a.id_tipodt = b.id_tipodt',
'AND a.id_declaratoria = :P207_ID_DECLARATORIA',
'ORDER BY b.nombre_tipodt'))
,p_read_only_when_type=>'ALWAYS'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P207_ID_DECLARATORIA'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(38204582399358149)
,p_query_column_id=>1
,p_column_alias=>'NOMBRE_TIPODT'
,p_column_display_sequence=>1
,p_column_heading=>unistr('Tipo Declaraci\00F3n Tur\00EDstica')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(38477540831951102)
,p_name=>'Oficios Relacionados'
,p_parent_plug_id=>wwv_flow_api.id(38201948161358123)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent4:t-Region--scrollBody'
,p_component_template_options=>'t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT anotaciones.num_oficio, anotaciones.fecha_oficio, sys.dbms_lob.getlength(anotaciones.oficio) Descargar,',
'anotaciones.tarchivo_oficio, anotaciones.NOMBRE_ARCHIVO, anotaciones.usuario_envia',
'FROM anotaciones',
'WHERE anotaciones.id_declaratoria = :P207_ID_DECLARATORIA'))
,p_read_only_when_type=>'ALWAYS'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P207_ID_DECLARATORIA'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(38477802081951105)
,p_query_column_id=>1
,p_column_alias=>'NUM_OFICIO'
,p_column_display_sequence=>1
,p_column_heading=>unistr('N\00B0 de Oficio')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(38477999699951106)
,p_query_column_id=>2
,p_column_alias=>'FECHA_OFICIO'
,p_column_display_sequence=>3
,p_column_heading=>'Fecha de Registro'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(38980935859143848)
,p_query_column_id=>3
,p_column_alias=>'DESCARGAR'
,p_column_display_sequence=>4
,p_column_heading=>'Descargar'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:ANOTACIONES:OFICIO:NUM_OFICIO::TARCHIVO_OFICIO:NOMBRE_ARCHIVO:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(38478197238951108)
,p_query_column_id=>4
,p_column_alias=>'TARCHIVO_OFICIO'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39262370890923712)
,p_query_column_id=>5
,p_column_alias=>'NOMBRE_ARCHIVO'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(38478278379951109)
,p_query_column_id=>6
,p_column_alias=>'USUARIO_ENVIA'
,p_column_display_sequence=>2
,p_column_heading=>'Registrado por'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(38604833692717378)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(38173793925310380)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(36380398837894382)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(38174114610310380)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(38173793925310380)
,p_button_name=>'CERRAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(36468943774894349)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38159438985310360)
,p_name=>'P207_ID_EMPRESA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(38201817475358122)
,p_item_source_plug_id=>wwv_flow_api.id(38158701472310344)
,p_source=>'ID_EMPRESA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38159859175310363)
,p_name=>'P207_NOMBRE_SOLICITANTE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(38201817475358122)
,p_item_source_plug_id=>wwv_flow_api.id(38158701472310344)
,p_prompt=>'Nombre del Solicitante'
,p_source=>'NOMBRE_SOLICITANTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38160220455310365)
,p_name=>'P207_RAZON_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(38201817475358122)
,p_item_source_plug_id=>wwv_flow_api.id(38158701472310344)
,p_prompt=>unistr('Raz\00F3n Social')
,p_source=>'RAZON_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38160684158310365)
,p_name=>'P207_NOMBRE_COMERCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(38201817475358122)
,p_item_source_plug_id=>wwv_flow_api.id(38158701472310344)
,p_prompt=>'Nombre Comercial'
,p_source=>'NOMBRE_COMERCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38161019440310366)
,p_name=>'P207_TELEFONO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(38201817475358122)
,p_item_source_plug_id=>wwv_flow_api.id(38158701472310344)
,p_prompt=>unistr('Tel\00E9fono')
,p_source=>'TELEFONO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38161445033310366)
,p_name=>'P207_CORREO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(38201817475358122)
,p_item_source_plug_id=>wwv_flow_api.id(38158701472310344)
,p_prompt=>'Correo'
,p_source=>'CORREO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38161897423310366)
,p_name=>'P207_ID_PROVINCIA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(38201817475358122)
,p_item_source_plug_id=>wwv_flow_api.id(38158701472310344)
,p_prompt=>'Provincia'
,p_source=>'ID_PROVINCIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_PROVINCIAS'
,p_lov=>'select descripcion,id from PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38162660590310367)
,p_name=>'P207_ID_DECLARATORIA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(38201948161358123)
,p_item_source_plug_id=>wwv_flow_api.id(38158701472310344)
,p_prompt=>'ID Declaratoria'
,p_source=>'ID_DECLARATORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38163054432310367)
,p_name=>'P207_FECHA_REGISTRO'
,p_source_data_type=>'DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(38201948161358123)
,p_item_source_plug_id=>wwv_flow_api.id(38158701472310344)
,p_prompt=>'Fecha de Registro'
,p_source=>'FECHA_REGISTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>55
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38163416384310367)
,p_name=>'P207_ID_ANALISTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(38201948161358123)
,p_item_source_plug_id=>wwv_flow_api.id(38158701472310344)
,p_prompt=>'Analista Asignado'
,p_source=>'ID_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38163849936310368)
,p_name=>'P207_FECHA_ASIG_ANALISTA'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(38201948161358123)
,p_item_source_plug_id=>wwv_flow_api.id(38158701472310344)
,p_prompt=>unistr('Fecha de Asignaci\00F3n al Analista')
,p_source=>'FECHA_ASIG_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38164206131310368)
,p_name=>'P207_ID_INSPECTOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(38201948161358123)
,p_item_source_plug_id=>wwv_flow_api.id(38158701472310344)
,p_prompt=>'Inspector Asignado'
,p_source=>'ID_INSPECTOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38165054324310368)
,p_name=>'P207_ESTADODT'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(38201948161358123)
,p_item_source_plug_id=>wwv_flow_api.id(38158701472310344)
,p_prompt=>unistr('Estado del Tr\00E1mite')
,p_source=>'ESTADODT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_ESTADOS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ESTADOS_TRAMITES.ID_ESTADO as ID_ESTADO,',
'    ESTADOS_TRAMITES.DESCRIPCION_ESTADO as DESCRIPCION_ESTADO ',
' from ESTADOS_TRAMITES ESTADOS_TRAMITES'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38203709982358141)
,p_name=>'P207_NOMBRE_TIPODT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(38204482579358148)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38479068146951117)
,p_name=>'P207_FECHA_ASIG_INSPECTOR'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(38201948161358123)
,p_item_source_plug_id=>wwv_flow_api.id(38158701472310344)
,p_prompt=>unistr('Fecha de Asignaci\00F3n al Inspector')
,p_source=>'FECHA_ASIG_INSPECTOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(38174269203310380)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(38174114610310380)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(38175043300310386)
,p_event_id=>wwv_flow_api.id(38174269203310380)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(38204125310358145)
,p_name=>'DAC_TipoDT'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'unload'
,p_display_when_type=>'NEVER'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(38204276230358146)
,p_event_id=>wwv_flow_api.id(38204125310358145)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    VnOMBRE VARCHAR2(55);',
'    cursor c_nombredt is',
'    Select DISTINCT b.nombre_tipodt From tdt_solicitud a, tipo_declaratoria b ',
'    where a.id_tipodt = b.id_tipodt',
'    and a.id_declaratoria =  :P207_ID_DECLARATORIA;',
'    ',
'begin ',
'',
'    open c_nombredt;',
'    fetch c_nombredt into VnOMBRE;',
'    close c_nombredt;',
'    ',
'    :P207_NOMBRE_TIPODT := VnOMBRE;',
'',
'end;'))
,p_attribute_02=>'P207_ID_DECLARATORIA'
,p_attribute_03=>'P207_NOMBRE_TIPODT'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(38177388294310388)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(38158701472310344)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Formulario Seguimiento Declaraciones'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(38177745698310388)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(38176937296310388)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(38158701472310344)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Formulario Seguimiento Declaraciones'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
