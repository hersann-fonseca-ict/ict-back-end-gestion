prompt --application/pages/page_00207
begin
--   Manifest
--     PAGE: 00207
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>207
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>unistr('Modal: Seguimiento de Declaraciones y Contratos Tur\00EDsticos')
,p_alias=>'MODAL-SEGUIMIENTO-DT-CT'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Seguimiento de Declaraciones y Contratos Tur\00EDsticos')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'600'
,p_dialog_width=>'1300'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20241022103754'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(38173793925310380)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(36380398837894382)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(505886852297450850)
,p_plug_name=>'Datos de la Empresa'
,p_region_template_options=>'#DEFAULT#:t-Region--controlsPosEnd:is-collapsed:t-Region--accent3:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36389817495894378)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_EMPRESA,',
'       NOMBRE_SOLICITANTE,',
'       TIPO_CEDULA,',
'       NACIONAL,',
'       CEDULA,',
'       RAZON_SOCIAL,',
'       NOMBRE_COMERCIAL,',
'       TELEFONO,',
'       CORREO,',
'       ID_PROVINCIA,',
'       ID_CANTON,',
'       ID_DISTRITO,',
'       DIRECCION_EXACTA',
'  from EMPRESA',
' where ID_EMPRESA = :P207_ID_EMPRESA'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(505894393757452195)
,p_plug_name=>unistr('Datos de la Declaratoria Tur\00EDstica')
,p_region_template_options=>'#DEFAULT#:t-Region--controlsPosEnd:is-collapsed:t-Region--accent5:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36389817495894378)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_DECLARATORIA,',
'       CANTIDAD_COLABORADORES,',
'       MONEDA,',
'       MONTO_INVERSION,',
'       ID_ANALISTA,',
'       FECHA_ASIG_ANALISTA,',
'       ID_INSPECTOR,',
'       FECHA_ASIG_INSPECTOR,',
'       FECHA_REGISTRO,',
'       ESTADODT',
'  from DECLARATORIA_TURISTICA WHERE ID_EMPRESA = :P207_ID_EMPRESA'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(505896477126452215)
,p_name=>unistr('Tipos de Declaratoria Tur\00EDstica')
,p_parent_plug_id=>wwv_flow_api.id(505894393757452195)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent4:t-Region--scrollBody:margin-top-sm'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'	b.nombre_tipodt ',
'FROM tdt_solicitud a, tipo_declaratoria b ',
'WHERE a.id_tipodt = b.id_tipodt AND a.id_declaratoria = :P207_ID_DECLARATORIA ORDER BY b.nombre_tipodt'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(254223514199900576)
,p_query_column_id=>1
,p_column_alias=>'NOMBRE_TIPODT'
,p_column_display_sequence=>1
,p_column_heading=>unistr('Tipo de Declaraci\00F3n Tur\00EDstica')
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(546583551085026921)
,p_name=>'Oficios Relacionados'
,p_parent_plug_id=>wwv_flow_api.id(505894393757452195)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent4:t-Region--scrollBody:margin-top-sm'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NUM_OFICIO,',
'       sys.dbms_lob.getlength(OFICIO) Descargar,',
'       TARCHIVO_OFICIO,',
'       USUARIO_ENVIA,',
'       ID_DECLARATORIA,',
'       ID_CONTRATO,',
'       FECHA_OFICIO,',
'       NOMBRE_ARCHIVO',
'FROM ANOTACIONES WHERE id_declaratoria = :P207_ID_DECLARATORIA AND ID_CONTRATO IS NULL ORDER BY FECHA_OFICIO DESC'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No se encontraron datos'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(254316522398312810)
,p_query_column_id=>1
,p_column_alias=>'NUM_OFICIO'
,p_column_display_sequence=>1
,p_column_heading=>unistr('N\00B0 de Oficio')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(254316163622312808)
,p_query_column_id=>2
,p_column_alias=>'DESCARGAR'
,p_column_display_sequence=>8
,p_column_heading=>'Descargar'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:ANOTACIONES:OFICIO:NUM_OFICIO::TARCHIVO_OFICIO:NOMBRE_ARCHIVO:::attachment::'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(254316901411312810)
,p_query_column_id=>3
,p_column_alias=>'TARCHIVO_OFICIO'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(254317389015312810)
,p_query_column_id=>4
,p_column_alias=>'USUARIO_ENVIA'
,p_column_display_sequence=>3
,p_column_heading=>'Registrado por'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(38604833692717378)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(254317739720312810)
,p_query_column_id=>5
,p_column_alias=>'ID_DECLARATORIA'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(254318182916312811)
,p_query_column_id=>6
,p_column_alias=>'ID_CONTRATO'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(254318504317312811)
,p_query_column_id=>7
,p_column_alias=>'FECHA_OFICIO'
,p_column_display_sequence=>6
,p_column_heading=>'Fecha de Registro'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(254318968075312811)
,p_query_column_id=>8
,p_column_alias=>'NOMBRE_ARCHIVO'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(505895381455116326)
,p_plug_name=>unistr('Datos del Contrato Tur\00EDstico')
,p_region_template_options=>'#DEFAULT#:t-Region--controlsPosEnd:is-collapsed:t-Region--accent1:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36389817495894378)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_CONTRATO,',
'       ID_ANALISTA,',
'       FECHA_ASIG_ANALISTA,',
'       ID_INSPECTOR,',
'       FECHA_ASIG_INSPECTOR,',
'       FECHA_REGISTRO,',
'       FECHA_CADUCIDAD,',
'       ESTADOCT',
'  from CONTRATO_TURISTICO',
' where ID_CONTRATO = :P207_ID_CONTRATO'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(545557339253159527)
,p_name=>'Oficios Relacionados'
,p_parent_plug_id=>wwv_flow_api.id(505895381455116326)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent4:t-Region--scrollBody:margin-top-sm'
,p_component_template_options=>'t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    anotaciones.num_oficio,',
'    anotaciones.fecha_oficio,',
'    sys.dbms_lob.getlength(anotaciones.oficio) Descargar,',
'    anotaciones.tarchivo_oficio,',
'    anotaciones.NOMBRE_ARCHIVO,',
'    anotaciones.usuario_envia',
'FROM anotaciones',
'WHERE anotaciones.ID_CONTRATO = :P207_ID_CONTRATO'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(254180707324477101)
,p_query_column_id=>1
,p_column_alias=>'NUM_OFICIO'
,p_column_display_sequence=>1
,p_column_heading=>unistr('N\00B0 de Oficio')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(254181139701477102)
,p_query_column_id=>2
,p_column_alias=>'FECHA_OFICIO'
,p_column_display_sequence=>4
,p_column_heading=>'Fecha de Registro'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(254181557680477102)
,p_query_column_id=>3
,p_column_alias=>'DESCARGAR'
,p_column_display_sequence=>5
,p_column_heading=>'Descargar'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:ANOTACIONES:OFICIO:NUM_OFICIO::TARCHIVO_OFICIO:NOMBRE_ARCHIVO:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(254181981473477103)
,p_query_column_id=>4
,p_column_alias=>'TARCHIVO_OFICIO'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(254182382693477103)
,p_query_column_id=>5
,p_column_alias=>'NOMBRE_ARCHIVO'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(254182715170477103)
,p_query_column_id=>6
,p_column_alias=>'USUARIO_ENVIA'
,p_column_display_sequence=>3
,p_column_heading=>'Registrado por'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(38604833692717378)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(38174114610310380)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(38173793925310380)
,p_button_name=>'CERRAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(36468943774894349)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254195026716555943)
,p_name=>'P207_ID_DECLARATORIA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(505894393757452195)
,p_item_source_plug_id=>wwv_flow_api.id(505894393757452195)
,p_prompt=>'ID Declaratoria'
,p_source=>'ID_DECLARATORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254195387811555946)
,p_name=>'P207_CANTIDAD_COLABORADORES'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(505894393757452195)
,p_item_source_plug_id=>wwv_flow_api.id(505894393757452195)
,p_prompt=>'Cantidad de Colaboradores'
,p_source=>'CANTIDAD_COLABORADORES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254195414188555947)
,p_name=>'P207_MONTO_INVERSION'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(505894393757452195)
,p_item_source_plug_id=>wwv_flow_api.id(505894393757452195)
,p_prompt=>unistr('Monto de Inversi\00F3n')
,p_format_mask=>'999G999G999G999G990D00'
,p_source=>'MONTO_INVERSION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254195564060555948)
,p_name=>'P207_ESTADODT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(505894393757452195)
,p_item_source_plug_id=>wwv_flow_api.id(505894393757452195)
,p_prompt=>unistr('Estado del Tr\00E1mite')
,p_source=>'ESTADODT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_ESTADOS_TRAMITES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ESTADOS_TRAMITES.ID_ESTADO as ID_ESTADO,',
'    ESTADOS_TRAMITES.DESCRIPCION_ESTADO as DESCRIPCION_ESTADO ',
' from ESTADOS_TRAMITES ESTADOS_TRAMITES'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254195604891555949)
,p_name=>'P207_MONEDA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(505894393757452195)
,p_item_source_plug_id=>wwv_flow_api.id(505894393757452195)
,p_prompt=>'Moneda'
,p_source=>'MONEDA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254195760171555950)
,p_name=>'P207_ID_ANALISTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(505894393757452195)
,p_item_source_plug_id=>wwv_flow_api.id(505894393757452195)
,p_prompt=>'Analista Asignado'
,p_source=>'ID_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre || '' '' || papellido AS nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254268159311025701)
,p_name=>'P207_ID_INSPECTOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(505894393757452195)
,p_item_source_plug_id=>wwv_flow_api.id(505894393757452195)
,p_prompt=>'Inspector Asignado'
,p_source=>'ID_INSPECTOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre || '' '' || papellido AS nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254268232211025702)
,p_name=>'P207_FECHA_REGISTRO'
,p_source_data_type=>'DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(505894393757452195)
,p_item_source_plug_id=>wwv_flow_api.id(505894393757452195)
,p_prompt=>'Fecha de Registro'
,p_source=>'FECHA_REGISTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254268398685025703)
,p_name=>'P207_FECHA_ASIG_ANALISTA'
,p_source_data_type=>'DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(505894393757452195)
,p_item_source_plug_id=>wwv_flow_api.id(505894393757452195)
,p_prompt=>unistr('Fecha de Asignaci\00F3n')
,p_source=>'FECHA_ASIG_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254268477499025704)
,p_name=>'P207_FECHA_ASIG_INSPECTOR'
,p_source_data_type=>'DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(505894393757452195)
,p_item_source_plug_id=>wwv_flow_api.id(505894393757452195)
,p_prompt=>unistr('Fecha de Asignaci\00F3n')
,p_source=>'FECHA_ASIG_INSPECTOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254269192811025711)
,p_name=>'P207_ID_CONTRATO'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(505895381455116326)
,p_item_source_plug_id=>wwv_flow_api.id(505895381455116326)
,p_prompt=>'ID Contrato'
,p_source=>'ID_CONTRATO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254269275373025712)
,p_name=>'P207_ID_ANALISTA_CT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(505895381455116326)
,p_item_source_plug_id=>wwv_flow_api.id(505895381455116326)
,p_prompt=>'Analista Asignado'
,p_source=>'ID_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre || '' '' || papellido AS nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254269373329025713)
,p_name=>'P207_FECHA_ASIG_ANALISTA_CT'
,p_source_data_type=>'DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(505895381455116326)
,p_item_source_plug_id=>wwv_flow_api.id(505895381455116326)
,p_prompt=>unistr('Fecha de Asignaci\00F3n')
,p_source=>'FECHA_ASIG_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254269438941025714)
,p_name=>'P207_ID_INSPECTOR_CT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(505895381455116326)
,p_item_source_plug_id=>wwv_flow_api.id(505895381455116326)
,p_prompt=>'Inspector Asignado'
,p_source=>'ID_INSPECTOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre || '' '' || papellido AS nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254269515794025715)
,p_name=>'P207_FECHA_ASIG_INSPECTOR_CT'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(505895381455116326)
,p_item_source_plug_id=>wwv_flow_api.id(505895381455116326)
,p_prompt=>unistr('Fecha de Asignaci\00F3n')
,p_source=>'FECHA_ASIG_INSPECTOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254269684961025716)
,p_name=>'P207_FECHA_REGISTRO_CT'
,p_source_data_type=>'DATE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(505895381455116326)
,p_item_source_plug_id=>wwv_flow_api.id(505895381455116326)
,p_prompt=>'Fecha de Registro'
,p_source=>'FECHA_REGISTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254269722876025717)
,p_name=>'P207_FECHA_CADUCIDAD'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(505895381455116326)
,p_item_source_plug_id=>wwv_flow_api.id(505895381455116326)
,p_prompt=>'Fecha de Caducidad'
,p_source=>'FECHA_CADUCIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254269884821025718)
,p_name=>'P207_ESTADOCT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(505895381455116326)
,p_item_source_plug_id=>wwv_flow_api.id(505895381455116326)
,p_prompt=>unistr('Estado del Tr\00E1mite')
,p_source=>'ESTADOCT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_ESTADOS_TRAMITES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ESTADOS_TRAMITES.ID_ESTADO as ID_ESTADO,',
'    ESTADOS_TRAMITES.DESCRIPCION_ESTADO as DESCRIPCION_ESTADO ',
' from ESTADOS_TRAMITES ESTADOS_TRAMITES'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254270316568025723)
,p_name=>'P207_ID_EMPRESA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(505886852297450850)
,p_item_source_plug_id=>wwv_flow_api.id(505886852297450850)
,p_source=>'ID_EMPRESA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254270449288025724)
,p_name=>'P207_NOMBRE_SOLICITANTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(505886852297450850)
,p_item_source_plug_id=>wwv_flow_api.id(505886852297450850)
,p_prompt=>'Nombre del Solicitante'
,p_source=>'NOMBRE_SOLICITANTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254270518152025725)
,p_name=>'P207_TIPO_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(505886852297450850)
,p_item_source_plug_id=>wwv_flow_api.id(505886852297450850)
,p_prompt=>unistr('Tipo de Identificaci\00F3n')
,p_source=>'TIPO_CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254270676700025726)
,p_name=>'P207_NACIONAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(505886852297450850)
,p_item_source_plug_id=>wwv_flow_api.id(505886852297450850)
,p_prompt=>'Nacional/Extranjero'
,p_source=>'NACIONAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254270772278025727)
,p_name=>'P207_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(505886852297450850)
,p_item_source_plug_id=>wwv_flow_api.id(505886852297450850)
,p_prompt=>unistr('N\00B0 de Identificaci\00F3n')
,p_source=>'CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254270879051025728)
,p_name=>'P207_RAZON_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(505886852297450850)
,p_item_source_plug_id=>wwv_flow_api.id(505886852297450850)
,p_prompt=>unistr('Raz\00F3n Social')
,p_source=>'RAZON_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254270904702025729)
,p_name=>'P207_NOMBRE_COMERCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(505886852297450850)
,p_item_source_plug_id=>wwv_flow_api.id(505886852297450850)
,p_prompt=>'Nombre Comercial'
,p_source=>'NOMBRE_COMERCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254271089234025730)
,p_name=>'P207_TELEFONO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(505886852297450850)
,p_item_source_plug_id=>wwv_flow_api.id(505886852297450850)
,p_prompt=>unistr('Tel\00E9fono')
,p_source=>'TELEFONO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254271124807025731)
,p_name=>'P207_CORREO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(505886852297450850)
,p_item_source_plug_id=>wwv_flow_api.id(505886852297450850)
,p_prompt=>'Correo'
,p_source=>'CORREO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>60
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254271297183025732)
,p_name=>'P207_ID_CANTON'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(505886852297450850)
,p_item_source_plug_id=>wwv_flow_api.id(505886852297450850)
,p_prompt=>unistr('Cant\00F3n')
,p_source=>'ID_CANTON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion,id from CANTONES@consulta_ictx where prov_id = :P207_ID_PROVINCIA;'
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P207_ID_PROVINCIA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254271386213025733)
,p_name=>'P207_ID_DISTRITO'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(505886852297450850)
,p_item_source_plug_id=>wwv_flow_api.id(505886852297450850)
,p_prompt=>'Distrito'
,p_source=>'ID_DISTRITO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion,id from DISTRITOS@consulta_ictx where prov_id = :P207_ID_PROVINCIA and canton_id = :P207_ID_CANTON;'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254271443173025734)
,p_name=>'P207_DIRECCION_EXACTA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(505886852297450850)
,p_item_source_plug_id=>wwv_flow_api.id(505886852297450850)
,p_prompt=>unistr('Direcci\00F3n Exacta')
,p_source=>'DIRECCION_EXACTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>300
,p_cHeight=>5
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(254271711523025737)
,p_name=>'P207_ID_PROVINCIA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(505886852297450850)
,p_item_source_plug_id=>wwv_flow_api.id(505886852297450850)
,p_prompt=>'Provincia'
,p_source=>'ID_PROVINCIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_PROVINCIAS'
,p_lov=>'select descripcion,id from PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(38174269203310380)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(38174114610310380)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(38175043300310386)
,p_event_id=>wwv_flow_api.id(38174269203310380)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(254320346436338502)
,p_name=>'DAC_ID_CONTRATO_IS_NOT_NULL'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P207_ID_CONTRATO'
,p_condition_element=>'P207_ID_CONTRATO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(254320766088338506)
,p_event_id=>wwv_flow_api.id(254320346436338502)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(505895381455116326)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(254322230439338507)
,p_event_id=>wwv_flow_api.id(254320346436338502)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(505895381455116326)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(254324112082342224)
,p_name=>'DAC_TIPO_CEDULA_JURIDICA'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P207_TIPO_CEDULA'
,p_condition_element=>'P207_TIPO_CEDULA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>unistr('Jur\00EDdica')
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(254324511156342225)
,p_event_id=>wwv_flow_api.id(254324112082342224)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P207_NOMBRE_SOLICITANTE,P207_NACIONAL,P207_CEDULA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(254325057059342225)
,p_event_id=>wwv_flow_api.id(254324112082342224)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P207_RAZON_SOCIAL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(38177745698310388)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(254271668048025736)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(505886852297450850)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize: Datos de la Empresa'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(254271517075025735)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(505894393757452195)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize: Datos de la Declaratoria Tur\00EDstica')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(254142465439997431)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(505895381455116326)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize: Datos del Contrato Tur\00EDstico')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
