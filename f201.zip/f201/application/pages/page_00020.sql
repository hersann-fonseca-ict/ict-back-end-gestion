prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>20
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>unistr('Modal: Gesti\00F3n de Transportes Acu\00E1ticos')
,p_alias=>'MODAL-GESTION-TRANS-ACUATICOS'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Datos del Transporte Acu\00E1tico')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function validateText(event) {',
'  var keyCode = event.keyCode;',
'  var excludedKeys = [8, 37, 39, 46, 32];',
'',
'  if (!((keyCode >= 65 && keyCode <= 90) ||',
'      (excludedKeys.includes(keyCode)))) {',
'    event.preventDefault();',
'',
'  }',
'} '))
,p_step_template=>wwv_flow_api.id(36356737605894393)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20240919113209'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15748267344058608)
,p_plug_name=>unistr('Datos Transporte Acu\00E1tico')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_api.id(36416259815894368)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'CATALOGO_CATEGORIA'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15751165812058607)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(15748267344058608)
,p_button_name=>'CANCELAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--padTop'
,p_button_template_id=>wwv_flow_api.id(36468943774894349)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15753163819058605)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(15748267344058608)
,p_button_name=>'ACTUALIZAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--iconRight:t-Button--padTop'
,p_button_template_id=>wwv_flow_api.id(36469031726894349)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Actualizar'
,p_button_position=>'BELOW_BOX'
,p_button_execute_validations=>'N'
,p_button_condition=>'P20_ID_CATEGORIA'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-save-as'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15753518646058605)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(15748267344058608)
,p_button_name=>'CREAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--iconRight:t-Button--padTop'
,p_button_template_id=>wwv_flow_api.id(36469031726894349)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_execute_validations=>'N'
,p_button_condition=>'P20_ID_CATEGORIA'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16196771507030237)
,p_name=>'P20_ID_CATEGORIA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(15748267344058608)
,p_item_source_plug_id=>wwv_flow_api.id(15748267344058608)
,p_item_default=>'SEQ_CAT_TIPODT'
,p_item_default_type=>'SEQUENCE'
,p_source=>'ID_CATEGORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16196865019030238)
,p_name=>'P20_DESCRIPCION_CATEGORIA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(15748267344058608)
,p_item_source_plug_id=>wwv_flow_api.id(15748267344058608)
,p_prompt=>unistr('Descripci\00F3n del Transporte Acu\00E1tico')
,p_source=>'DESCRIPCION_CATEGORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16196958033030239)
,p_name=>'P20_ESTADO_CATEGORIA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(15748267344058608)
,p_item_source_plug_id=>wwv_flow_api.id(15748267344058608)
,p_prompt=>unistr('Estado del Transporte Acu\00E1tico')
,p_source=>'ESTADO_CATEGORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_ESTADO'
,p_lov=>'select nombre_estado, codigo_estado from estados_tramite@consulta_ictx where codigo_estado = ''AC'' or codigo_estado = ''IA'''
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16197067793030240)
,p_name=>'P20_ID_TIPODT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(15748267344058608)
,p_item_source_plug_id=>wwv_flow_api.id(15748267344058608)
,p_item_default=>'6'
,p_source=>'ID_TIPODT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(252107454006004528)
,p_validation_name=>'VAL_DESCRIPCION_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P20_DESCRIPCION_CATEGORIA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar la descripci\00F3n del transporte acu\00E1tico')
,p_always_execute=>'Y'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(252107767842005533)
,p_validation_name=>'VAL_ESTADO_NOT_NULL'
,p_validation_sequence=>20
,p_validation=>'P20_ESTADO_CATEGORIA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar el estado del transporte acu\00E1tico')
,p_always_execute=>'Y'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(15751263260058607)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(15751165812058607)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15752029848058606)
,p_event_id=>wwv_flow_api.id(15751263260058607)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(252106526831002275)
,p_name=>'VALIDATE_SOLO_LETRAS'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P20_DESCRIPCION_CATEGORIA'
,p_bind_type=>'bind'
,p_bind_event_type=>'keydown'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(252106977777002280)
,p_event_id=>wwv_flow_api.id(252106526831002275)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'validateText(event);'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15754362412058605)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(15748267344058608)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('Process form Formulario Transporte Acu\00E1tico')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15754715021058603)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CANCELAR, ACTUALIZAR, CREAR'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15753907236058605)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(15748267344058608)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Formulario Transporte Acu\00E1tico')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
