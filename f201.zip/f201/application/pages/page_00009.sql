prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>9
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>unistr('Form: Analisis de Contratos Tur\00EDsticos')
,p_alias=>'FORM-ANALISIS-CT'
,p_step_title=>unistr('Analisis de Contratos Tur\00EDsticos')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20241024131626'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(544671297267465715)
,p_plug_name=>unistr('Tabla: Declaratorias Tur\00EDsticas')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(36404937346894372)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'	e.id_empresa,',
'	dt.id_declaratoria,',
'    ct.id_contrato,',
'	e.nombre_solicitante,',
'	e.tipo_cedula,',
'	e.razon_social,',
'	e.nombre_comercial,',
'	e.telefono,',
'	e.correo,',
'	e.id_provincia,',
'	ct.fecha_registro,',
'	ct.estadoct',
'FROM empresa e',
'	INNER JOIN declaratoria_turistica dt ON e.id_empresa = dt.id_empresa',
'    INNER JOIN contrato_turistico ct ON ct.ID_DECLARATORIA = dt.id_declaratoria',
'	WHERE ct.id_analista = PKG_USUARIOS.Consulta_usuario(:APP_USER)',
'	OR ct.ID_INSPECTOR = PKG_USUARIOS.Consulta_usuario(:APP_USER)',
'    ORDER BY dt.id_declaratoria DESC'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Listado de las Declaratorias Tur\00EDsticas por revisar')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(505554862175226703)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No se encontraron datos'
,p_allow_report_saving=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_select_columns=>'N'
,p_show_rows_per_page=>'N'
,p_show_filter=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'CSV:HTML'
,p_download_filename=>'reporte-contrato-turistico'
,p_owner=>'HERSANN.FONSECA'
,p_internal_uid=>505554862175226703
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(253135355450038842)
,p_db_column_name=>'ID_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'S'
,p_column_label=>'Ver Detalles'
,p_column_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::P8_ID_EMPRESA,P8_ID_DECLARATORIA,P8_ID_CONTRATO:#ID_EMPRESA#,#ID_DECLARATORIA#,#ID_CONTRATO#'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-window-search"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(253135472026038843)
,p_db_column_name=>'ID_DECLARATORIA'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'ID Declaratoria'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(253135560288038844)
,p_db_column_name=>'ID_CONTRATO'
,p_display_order=>30
,p_column_identifier=>'U'
,p_column_label=>'ID Contrato'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(253135697895038845)
,p_db_column_name=>'NOMBRE_SOLICITANTE'
,p_display_order=>40
,p_column_identifier=>'V'
,p_column_label=>'Nombre Solicitante'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(253135799366038846)
,p_db_column_name=>'TIPO_CEDULA'
,p_display_order=>50
,p_column_identifier=>'W'
,p_column_label=>'Tipo Cedula'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(253135847898038847)
,p_db_column_name=>'RAZON_SOCIAL'
,p_display_order=>60
,p_column_identifier=>'X'
,p_column_label=>'Razon Social'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(253135960092038848)
,p_db_column_name=>'NOMBRE_COMERCIAL'
,p_display_order=>70
,p_column_identifier=>'Y'
,p_column_label=>'Nombre Comercial'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(253136003263038849)
,p_db_column_name=>'TELEFONO'
,p_display_order=>80
,p_column_identifier=>'Z'
,p_column_label=>'Telefono'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(253136126339038850)
,p_db_column_name=>'CORREO'
,p_display_order=>90
,p_column_identifier=>'AA'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(253195524237068501)
,p_db_column_name=>'ID_PROVINCIA'
,p_display_order=>100
,p_column_identifier=>'AB'
,p_column_label=>'Provincia'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_api.id(19980461641459915)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(253195635550068502)
,p_db_column_name=>'FECHA_REGISTRO'
,p_display_order=>110
,p_column_identifier=>'AC'
,p_column_label=>'Fecha de Registro'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(253195888218068504)
,p_db_column_name=>'ESTADOCT'
,p_display_order=>120
,p_column_identifier=>'AE'
,p_column_label=>unistr('Estado del Tr\00E1mite')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_api.id(161672685883171523)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(505571377648230479)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2531797'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_EMPRESA:ID_DECLARATORIA:ID_CONTRATO:NOMBRE_SOLICITANTE:TIPO_CEDULA:RAZON_SOCIAL:NOMBRE_COMERCIAL:TELEFONO:CORREO:ID_PROVINCIA:FECHA_REGISTRO:ESTADOCT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2888547428703625102)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36406847262894371)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>An\00E1lisis de Contratos Tur\00EDsticos</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
