prompt --application/pages/page_00203
begin
--   Manifest
--     PAGE: 00203
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>203
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>'Legacy: FormularioDT_Anotaciones'
,p_alias=>'FORM-DT-ANOTACIONES-LEGACY'
,p_step_title=>'FormularioDT_Anotaciones'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20241017132724'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39107647232376195)
,p_plug_name=>unistr('An\00E1lisis Declaratorias Tur\00EDsticas')
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36406847262894371)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT empresa.ROWID, empresa.id_empresa , empresa.nombre_solicitante,  empresa.tipo_cedula,empresa.cedula, ',
'  empresa.nacional, empresa.razon_social, empresa.nombre_comercial,',
' empresa.telefono, empresa.correo ,empresa.id_provincia, empresa.id_canton, empresa.id_distrito, empresa.direccion_exacta,',
'',
' declaratoria_turistica.id_declaratoria ,declaratoria_turistica.cantidad_colaboradores ,',
' declaratoria_turistica.moneda, declaratoria_turistica.monto_inversion, ',
'/* ',
' sys.dbms_lob.getlength(declaratoria_turistica.SOLICITUD) Solicitud,',
' sys.dbms_lob.getlength(declaratoria_turistica.DESCRIPCION) Descipcion,',
'  declaratoria_turistica.TSOLICITUD, declaratoria_turistica.TDESCRIPCION,',
'*/',
'  operacion_dt.id_operacion_dt, operacion_dt.si_operacion, --operacion_dt.permiso_salud, operacion_dt.cronograma, operacion_dt.patente_municipal,',
' sys.dbms_lob.getlength(operacion_dt.permiso_salud) Permiso_Salud,',
' sys.dbms_lob.getlength(operacion_dt.cronograma) Cronograma,',
' sys.dbms_lob.getlength(operacion_dt.patente_municipal) Patente,',
' operacion_dt.tarchivo_permiso, operacion_dt.tarchivo_cronograma,',
' operacion_dt.tarchivo_patente',
'',
'FROM empresa',
'  JOIN declaratoria_turistica ON empresa.id_empresa = declaratoria_turistica.id_empresa ',
'    ',
'  JOIN operacion_dt ON operacion_dt.id_declaratoria = declaratoria_turistica.id_declaratoria',
' ',
' WHERE declaratoria_turistica.id_analista IS NOT NULL'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39072976311200850)
,p_plug_name=>'Datos de la empresa'
,p_parent_plug_id=>wwv_flow_api.id(39107647232376195)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36406847262894371)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39183735328922934)
,p_plug_name=>'Adjuntar Oficios'
,p_parent_plug_id=>wwv_flow_api.id(39072976311200850)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36406847262894371)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'ANOTACIONES'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39148904940437301)
,p_plug_name=>'Datos de la declaratoria'
,p_parent_plug_id=>wwv_flow_api.id(39107647232376195)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36406847262894371)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(38648838486961128)
,p_name=>unistr('Archivos de la Operaci\00F3n')
,p_parent_plug_id=>wwv_flow_api.id(39148904940437301)
,p_template=>wwv_flow_api.id(36406847262894371)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_OPERACION_DT,',
'sys.dbms_lob.getlength(PERMISO_SALUD) Permiso, TARCHIVO_PERMISO, NARCHIVO_PERMISO,',
'sys.dbms_lob.getlength(CRONOGRAMA) Cronograma, TARCHIVO_CRONOGRAMA, NARCHIVO_CRONOGRAMA,',
'sys.dbms_lob.getlength(PATENTE_MUNICIPAL) Patente, TARCHIVO_PATENTE NARCHIVO_PATENTE',
'  from OPERACION_DT',
'where ID_OPERACION_DT = :P203_ID_OPERACION_DT AND ID_DECLARATORIA = :P203_ID_DECLARATORIA'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(38650850030961148)
,p_query_column_id=>1
,p_column_alias=>'ID_OPERACION_DT'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40160833263303824)
,p_query_column_id=>2
,p_column_alias=>'PERMISO'
,p_column_display_sequence=>3
,p_column_heading=>'Permiso Salud'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:OPERACION_DT:PERMISO_SALUD:ID_OPERACION_DT::TARCHIVO_PERMISO:NARCHIVO_PERMISO:::attachment:Descargar:'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40160975815303825)
,p_query_column_id=>3
,p_column_alias=>'TARCHIVO_PERMISO'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39321639861748904)
,p_query_column_id=>4
,p_column_alias=>'NARCHIVO_PERMISO'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40161071334303826)
,p_query_column_id=>5
,p_column_alias=>'CRONOGRAMA'
,p_column_display_sequence=>5
,p_column_heading=>'Cronograma'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:OPERACION_DT:CRONOGRAMA:ID_OPERACION_DT::TARCHIVO_CRONOGRAMA:NARCHIVO_CRONOGRAMA:::attachment:Descargar:'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40161193402303827)
,p_query_column_id=>6
,p_column_alias=>'TARCHIVO_CRONOGRAMA'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40161262113303828)
,p_query_column_id=>7
,p_column_alias=>'NARCHIVO_CRONOGRAMA'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40161333700303829)
,p_query_column_id=>8
,p_column_alias=>'PATENTE'
,p_column_display_sequence=>8
,p_column_heading=>'Patente Municipal'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:OPERACION_DT:PATENTE_MUNICIPAL:ID_OPERACION_DT::TARCHIVO_PATENTE:NARCHIVO_PATENTE:::attachment:Descargar:'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(40161421602303830)
,p_query_column_id=>9
,p_column_alias=>'NARCHIVO_PATENTE'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(39149158729437303)
,p_name=>'Tipo Declaratoria'
,p_parent_plug_id=>wwv_flow_api.id(39148904940437301)
,p_template=>wwv_flow_api.id(36406847262894371)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tdt_solicitud.id_solicitud , tdt_solicitud.id_catalogo, tdt_solicitud.id_tipodt, ',
'sys.dbms_lob.getlength(tdt_solicitud.archivo) Descargar,',
' tdt_solicitud.aprob_cimat , tdt_solicitud.flotilla_rent_car,  tdt_solicitud.nombre_archivo, tdt_solicitud.id_certif_sttt ,',
' tdt_solicitud.zona_indigena , tdt_solicitud.tarchivo,',
'',
'   (SELECT tipo_declaratoria.nombre_tipodt FROM tipo_declaratoria ',
'  WHERE tipo_declaratoria.id_tipodt = tdt_solicitud.id_tipodt) as "Tipo",',
'  ',
'  (SELECT catalogo_categoria.descripcion_categoria FROM catalogo_categoria ',
unistr('  WHERE catalogo_categoria.id_categoria = tdt_solicitud.id_catalogo) as "Categor\00EDa"'),
'  ',
'  FROM tdt_solicitud',
'  ',
'  WHERE tdt_solicitud.id_declaratoria = :P203_ID_DECLARATORIA'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39149256828437304)
,p_query_column_id=>1
,p_column_alias=>'ID_SOLICITUD'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39149356247437305)
,p_query_column_id=>2
,p_column_alias=>'ID_CATALOGO'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39149474656437306)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPODT'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39149546640437307)
,p_query_column_id=>4
,p_column_alias=>'DESCARGAR'
,p_column_display_sequence=>4
,p_column_heading=>'Descargar'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:TDT_SOLICITUD:ARCHIVO:ID_SOLICITUD::TARCHIVO:NOMBRE_ARCHIVO:::attachment:Ver:'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39149671458437308)
,p_query_column_id=>5
,p_column_alias=>'APROB_CIMAT'
,p_column_display_sequence=>5
,p_column_heading=>'Aprob Cimat'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P203_VALIDACION_CIMAT'
,p_display_when_condition2=>'S'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39149716112437309)
,p_query_column_id=>6
,p_column_alias=>'FLOTILLA_RENT_CAR'
,p_column_display_sequence=>6
,p_column_heading=>'Flotilla Rent Car'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39149823634437310)
,p_query_column_id=>7
,p_column_alias=>'NOMBRE_ARCHIVO'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39149915403437311)
,p_query_column_id=>8
,p_column_alias=>'ID_CERTIF_STTT'
,p_column_display_sequence=>8
,p_column_heading=>'Certificado STTT'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39150021582437312)
,p_query_column_id=>9
,p_column_alias=>'ZONA_INDIGENA'
,p_column_display_sequence=>9
,p_column_heading=>'Zona Indigena'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39150122154437313)
,p_query_column_id=>10
,p_column_alias=>'TARCHIVO'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39150217828437314)
,p_query_column_id=>11
,p_column_alias=>'Tipo'
,p_column_display_sequence=>11
,p_column_heading=>'Tipo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39150305272437315)
,p_query_column_id=>12
,p_column_alias=>unistr('Categor\00EDa')
,p_column_display_sequence=>12
,p_column_heading=>unistr('Categor\00EDa')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(39184618881922943)
,p_name=>'Oficios Relacionados'
,p_parent_plug_id=>wwv_flow_api.id(39148904940437301)
,p_template=>wwv_flow_api.id(36406847262894371)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_OFICIO,  ',
'sys.dbms_lob.getlength(OFICIO) Descargar,',
' TARCHIVO_OFICIO, NOMBRE_ARCHIVO, USUARIO_ENVIA, FECHA_OFICIO',
'',
'  FROM anotaciones',
'  ',
'  WHERE anotaciones.id_declaratoria = :P203_ID_DECLARATORIA'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39261795277923706)
,p_query_column_id=>1
,p_column_alias=>'NUM_OFICIO'
,p_column_display_sequence=>1
,p_column_heading=>unistr('N\00FAmero Oficio')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39261874438923707)
,p_query_column_id=>2
,p_column_alias=>'TARCHIVO_OFICIO'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39262240649923711)
,p_query_column_id=>3
,p_column_alias=>'NOMBRE_ARCHIVO'
,p_column_display_sequence=>5
,p_column_heading=>'Descargar'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:ANOTACIONES:OFICIO:NUM_OFICIO::TARCHIVO_OFICIO:NOMBRE_ARCHIVO:::attachment::'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39261979204923708)
,p_query_column_id=>4
,p_column_alias=>'USUARIO_ENVIA'
,p_column_display_sequence=>3
,p_column_heading=>'Usuario'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(38604833692717378)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39262054721923709)
,p_query_column_id=>5
,p_column_alias=>'FECHA_OFICIO'
,p_column_display_sequence=>4
,p_column_heading=>'Fecha Oficio'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(173489308326460623)
,p_name=>unistr('Documentaci\00F3n')
,p_parent_plug_id=>wwv_flow_api.id(39148904940437301)
,p_template=>wwv_flow_api.id(36406847262894371)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_DECLARATORIA,',
'       sys.dbms_lob.getlength(SOLICITUD) SOLICITUD,',
'       TSOLICITUD,',
'       NSOLICITUD,',
'       sys.dbms_lob.getlength(DESCRIPCION) DESCRIPCION,',
'       TDESCRIPCION,',
'       NDESCRIPCION',
'  from DECLARATORIA_TURISTICA where ID_DECLARATORIA = :P203_ID_DECLARATORIA;'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No hay archivos'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(226798678979793219)
,p_query_column_id=>1
,p_column_alias=>'ID_DECLARATORIA'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(173490358458460633)
,p_query_column_id=>2
,p_column_alias=>'SOLICITUD'
,p_column_display_sequence=>1
,p_column_heading=>'Solicitud de la Declaratoria'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:DECLARATORIA_TURISTICA:SOLICITUD:ID_DECLARATORIA::TSOLICITUD:NSOLICITUD:::attachment:Descargar:'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(173490521897460635)
,p_query_column_id=>3
,p_column_alias=>'TSOLICITUD'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(173490770998460637)
,p_query_column_id=>4
,p_column_alias=>'NSOLICITUD'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(226799884765793231)
,p_query_column_id=>5
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>7
,p_column_heading=>unistr('Descripci\00F3n del Proyecto')
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:DECLARATORIA_TURISTICA:DESCRIPCION:ID_DECLARATORIA::TDESCRIPCION:NDESCRIPCION:::attachment:Descargar:'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(173490668236460636)
,p_query_column_id=>6
,p_column_alias=>'TDESCRIPCION'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(173490816805460638)
,p_query_column_id=>7
,p_column_alias=>'NDESCRIPCION'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2583879187786125021)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36406847262894371)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3> An\00E1lisis Declaratorias Tur\00EDsticas </h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39127434536376224)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(39183735328922934)
,p_button_name=>'btn_Guardar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(36468943774894349)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar Oficio'
,p_button_position=>'BELOW_BOX'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39126266607376221)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(39107647232376195)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(36468943774894349)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:::'
,p_button_condition_type=>'NEVER'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39127878236376224)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(39107647232376195)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(36468943774894349)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition_type=>'NEVER'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39127031806376224)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(39107647232376195)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(36468943774894349)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(39128196696376224)
,p_branch_action=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38650722271961147)
,p_name=>'P203_IDENT_ARC'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(38648838486961128)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39108075165376198)
,p_name=>'P203_ROWID'
,p_source_data_type=>'ROWID'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(39072976311200850)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_source=>'ROWID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39108430782376205)
,p_name=>'P203_ID_EMPRESA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(39072976311200850)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_source=>'ID_EMPRESA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39108891279376211)
,p_name=>'P203_NOMBRE_SOLICITANTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(39072976311200850)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>'Nombre Solicitante'
,p_source=>'NOMBRE_SOLICITANTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(36468105452894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39109213541376211)
,p_name=>'P203_TIPO_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(39072976311200850)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>unistr('Tipo de C\00E9dula')
,p_source=>'TIPO_CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39109680922376211)
,p_name=>'P203_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(39072976311200850)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>unistr('C\00E9dula')
,p_source=>'CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(36468105452894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39110092133376212)
,p_name=>'P203_NACIONAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(39072976311200850)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>'Nacional o Extranjero'
,p_source=>'NACIONAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39110499838376212)
,p_name=>'P203_RAZON_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(39072976311200850)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>unistr('Raz\00F3n Social')
,p_source=>'RAZON_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39110884965376212)
,p_name=>'P203_NOMBRE_COMERCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(39072976311200850)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>'Nombre Comercial'
,p_source=>'NOMBRE_COMERCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39111202298376213)
,p_name=>'P203_TELEFONO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(39072976311200850)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>unistr('Tel\00E9fono')
,p_source=>'TELEFONO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(36468105452894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39111624449376213)
,p_name=>'P203_CORREO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(39072976311200850)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>unistr('Correo electr\00F3nico')
,p_source=>'CORREO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(36468105452894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39112014959376213)
,p_name=>'P203_ID_PROVINCIA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(39072976311200850)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>'Provincia'
,p_source=>'ID_PROVINCIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_PROVINCIAS'
,p_lov=>'select descripcion,id from PROVINCIAS@consulta_ictx'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36468105452894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39112488658376213)
,p_name=>'P203_ID_CANTON'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(39072976311200850)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>unistr('Cant\00F3n')
,p_source=>'ID_CANTON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion, id from CANTONES@consulta_ictx WHERE prov_id = :P203_ID_PROVINCIA'
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P203_ID_PROVINCIA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36468105452894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39112851155376213)
,p_name=>'P203_ID_DISTRITO'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(39072976311200850)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>'Distrito'
,p_source=>'ID_DISTRITO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion, id from DISTRITOS@consulta_ictx WHERE prov_id = :P203_ID_PROVINCIA and canton_id = :P203_ID_CANTON'
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P203_ID_PROVINCIA,P203_ID_CANTON'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36468105452894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39113226147376214)
,p_name=>'P203_DIRECCION_EXACTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(39072976311200850)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>unistr('Direcci\00F3n Exacta')
,p_source=>'DIRECCION_EXACTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(36468105452894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39113612267376214)
,p_name=>'P203_ID_DECLARATORIA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(39148904940437301)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>'Id de la Declaratoria'
,p_source=>'ID_DECLARATORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39114019905376214)
,p_name=>'P203_CANTIDAD_COLABORADORES'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(39148904940437301)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>'Cantidad de Colaboradores'
,p_source=>'CANTIDAD_COLABORADORES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>100
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36468105452894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39114428522376214)
,p_name=>'P203_MONEDA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(39148904940437301)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>'Moneda'
,p_source=>'MONEDA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>20
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36468105452894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39114817324376215)
,p_name=>'P203_MONTO_INVERSION'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(39148904940437301)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>unistr('Monto de Inversi\00F3n')
,p_source=>'MONTO_INVERSION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>20
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36468105452894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39115203859376215)
,p_name=>'P203_ID_OPERACION_DT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(39148904940437301)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_source=>'ID_OPERACION_DT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39115680052376215)
,p_name=>'P203_SI_OPERACION'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(39148904940437301)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_prompt=>unistr('Operaci\00F3n')
,p_source=>'SI_OPERACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_OPERACION'
,p_lov=>'.'||wwv_flow_api.id(39624421094645434)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36468105452894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39116058497376216)
,p_name=>'P203_PERMISO_SALUD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(39148904940437301)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_source=>'PERMISO_SALUD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39116405135376216)
,p_name=>'P203_CRONOGRAMA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(39148904940437301)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_source=>'CRONOGRAMA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39116830775376216)
,p_name=>'P203_PATENTE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(39148904940437301)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_source=>'PATENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39117243884376216)
,p_name=>'P203_TARCHIVO_PERMISO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(39148904940437301)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_source=>'TARCHIVO_PERMISO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39117681782376216)
,p_name=>'P203_TARCHIVO_CRONOGRAMA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(39148904940437301)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_source=>'TARCHIVO_CRONOGRAMA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39118090436376217)
,p_name=>'P203_TARCHIVO_PATENTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(39148904940437301)
,p_item_source_plug_id=>wwv_flow_api.id(39107647232376195)
,p_source=>'TARCHIVO_PATENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39183947090922936)
,p_name=>'P203_NUM_OFICIO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(39183735328922934)
,p_item_source_plug_id=>wwv_flow_api.id(39183735328922934)
,p_prompt=>unistr('N\00FAmero de Oficio')
,p_source=>'NUM_OFICIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(36468051038894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39184002903922937)
,p_name=>'P203_OFICIO'
,p_source_data_type=>'BLOB'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(39183735328922934)
,p_item_source_plug_id=>wwv_flow_api.id(39183735328922934)
,p_prompt=>'Oficio'
,p_source=>'OFICIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39184179874922938)
,p_name=>'P203_TARCHIVO_OFICIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(39183735328922934)
,p_item_source_plug_id=>wwv_flow_api.id(39183735328922934)
,p_source=>'TARCHIVO_OFICIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39184209602922939)
,p_name=>'P203_USUARIO_ENVIA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(39183735328922934)
,p_item_source_plug_id=>wwv_flow_api.id(39183735328922934)
,p_source=>'USUARIO_ENVIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39184485830922941)
,p_name=>'P203_ID_CONTRATO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(39183735328922934)
,p_item_source_plug_id=>wwv_flow_api.id(39183735328922934)
,p_source=>'ID_CONTRATO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39184581714922942)
,p_name=>'P203_FECHA_OFICIO'
,p_source_data_type=>'DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(39183735328922934)
,p_item_source_plug_id=>wwv_flow_api.id(39183735328922934)
,p_source=>'FECHA_OFICIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40277876935968242)
,p_name=>'P203_VALIDACION_CIMAT'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(39148904940437301)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40277906500968243)
,p_name=>'P203_TIPOCORREO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(39183735328922934)
,p_use_cache_before_default=>'NO'
,p_prompt=>'A quien desea enviar el oficio'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:A la empresa;E,Interno ICT;I'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40278043051968244)
,p_name=>'P203_CORREOICT'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(39183735328922934)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Correo ICT'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(36467713238894350)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40480067757483227)
,p_name=>'P203_CUERPO_CORREO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(39183735328922934)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Que quieres que diga el correo'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>300
,p_cMaxlength=>300
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39183249337922929)
,p_name=>'New'
,p_event_sequence=>10
,p_condition_element=>'P203_CRONOGRAMA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_display_when_cond=>'P203_CRONOGRAMA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39183375384922930)
,p_event_id=>wwv_flow_api.id(39183249337922929)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(39127878236376224)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(40278112657968245)
,p_name=>'DAC_Correo'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P203_TIPOCORREO'
,p_condition_element=>'P203_TIPOCORREO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'I'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(40278260043968246)
,p_event_id=>wwv_flow_api.id(40278112657968245)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P203_CORREOICT'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(40278398185968247)
,p_event_id=>wwv_flow_api.id(40278112657968245)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P203_CORREOICT'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39183582136922932)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Download'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_xml clob; ',
'    l_blob blob; ',
'    l_lang_context integer := DBMS_LOB.DEFAULT_LANG_CTX; ',
'    l_warning integer := DBMS_LOB.WARN_INCONVERTIBLE_CHAR; ',
'    l_dest_offset integer := 1; ',
'    l_source_offset integer := 1; ',
'    l_name varchar2(250);',
'begin',
'    dbms_lob.createtemporary(l_blob, true); ',
'begin ',
'    Select CRONOGRAMA,NARCHIVO_CRONOGRAMA ',
'      into l_blob,l_name ',
'      from OPERACION_DT ',
'     where OPERACION_DT.ID_DECLARATORIA = :P203_ID_DECLARATORIA;',
'    exception when others then RETURN; ',
'    --apex_application.stop_apex_engine; ',
'    --owa_util.http_header_close; ',
'end; ',
'    /*if l_blob is null then return; end if;*/ ',
'    ',
'    htp.init;',
'    -- Set the MIME typebranck',
'    owa_util.mime_header( \''application/octet-stream\'', FALSE,\''UTF-8\'' );',
'    -- Set the name of the file ',
'    htp.p(\''Content-Disposition: attachment; filename=\"\''||l_name||\''\"\'');',
'    owa_util.http_header_close; ',
'    --package that provides an interface to download files (BLOBs and BFILEs)',
'    wpg_docload.download_file( l_blob ); ',
'    --stop further processing and immediately exit',
'    apex_application.stop_apex_engine; ',
'    exception when others then',
'    htp.prn(\''error: \''||sqlerrm); ',
'    apex_application.stop_apex_engine; ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DOWNLOAD'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39262195599923710)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Prc_Anotaciones'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vEstado NUMBER:= 0;',
'',
'begin',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'                 WHERE NAME = :P203_OFICIO;',
'                                        ',
'    PKG_DECLARATORIA.Insertar_Anotacion(:P203_NUM_OFICIO, vArchivo, vTipoArchivo, vNombreArchivo, :APP_USER, ',
'                                        :P203_ID_DECLARATORIA, null, vMensaje_Retorno, vRetorno);',
'                                        ',
'    if :P203_TIPOCORREO = ''E''',
'    then',
'       PKG_CORREOS.ENVIO_CORREO_ADJUN(:P203_CORREO,''Notificacion de su tramite de Declaratoria Turistica'',',
'                    :P203_CUERPO_CORREO, :P203_NUM_OFICIO);',
'      ',
'        vEstado := 4;                            ',
'    ',
'    else',
'        PKG_CORREOS.ENVIO_CORREO_ADJUN(:P203_CORREOICT, '' '' , :P203_CUERPO_CORREO, :P203_NUM_OFICIO);',
'     ',
'        vEstado := 5;                            ',
'    end if;',
'    ',
'    PKG_DECLARATORIA.Actualizar_Estado(:P203_ID_DECLARATORIA, vEstado);',
'     ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(39127434536376224)
,p_process_success_message=>unistr('Oficio agregado con \00E9xito!')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39128675262376226)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(39107647232376195)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form FormularioDT_Anotaciones'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(40277754529968241)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Prc_ValidaColumnasTipoDT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'aprCIMAT VARCHAR2(8);',
'',
'CURSOR cursorDT IS ',
'',
'select  tdt_solicitud.aprob_cimat  FROM tdt_solicitud WHERE tdt_solicitud.id_declaratoria = :P203_ID_DECLARATORIA;',
'',
'',
'begin',
'',
'OPEN cursorDT;',
'FETCH cursorDT INTO aprCIMAT;',
'CLOSE cursorDT;',
'',
'  if aprCIMAT is not null',
'  then',
'      :P203_VALIDACION_CIMAT := ''S'';',
'      else',
'      :P203_VALIDACION_CIMAT := ''N'';',
'  end if;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
