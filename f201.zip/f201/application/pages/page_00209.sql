prompt --application/pages/page_00209
begin
--   Manifest
--     PAGE: 00209
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>209
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>unistr('Modal: Seguimiento | Contratos Tur\00EDsticos')
,p_alias=>'MODAL-SEGUIMIENTO-DE-CONTRATOS'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Seguimiento de Contratos Tur\00EDsticos')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20240917131646'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40035385292692250)
,p_plug_name=>unistr('Seguimiento de Contratos Tur\00EDsticos')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(36379437477894382)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'	e.id_empresa,',
'	e.nombre_solicitante,',
'	e.razon_social,',
'	e.nombre_comercial,',
'	e.telefono,',
'	e.correo,',
'	e.id_provincia, ',
'	dt.id_declaratoria, ',
'	dt.fecha_registro as "FechaDT",',
'	dt.id_analista as "AnalistaDT",',
'	dt.fecha_asig_analista as "FAnalistaDT",',
'	dt.id_inspector as "InspectorDT",',
'	dt.fecha_asig_inspector as "FInspectorDT",',
'	dt.estadodt,',
'	ct.id_contrato,',
'	ct.fecha_registro, ',
'	ct.id_analista,',
'	ct.fecha_asig_analista,',
'	ct.id_inspector,',
'	ct.fecha_asig_inspector,',
'	ct.estadoct',
'FROM empresa e',
'	INNER JOIN declaratoria_turistica dt ON e.id_empresa = dt.id_empresa',
'	INNER JOIN contrato_turistico ct ON ct.ID_DECLARATORIA = dt.id_declaratoria'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39643332213928538)
,p_plug_name=>'Datos de la Empresa'
,p_parent_plug_id=>wwv_flow_api.id(40035385292692250)
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-expanded:t-Region--accent4:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36389817495894378)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_read_only_when_type=>'ALWAYS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39643468869928539)
,p_plug_name=>'Datos de la Declaratoria'
,p_parent_plug_id=>wwv_flow_api.id(40035385292692250)
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent5:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36389817495894378)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_read_only_when_type=>'ALWAYS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39643593459928540)
,p_plug_name=>'Datos del Contrato'
,p_parent_plug_id=>wwv_flow_api.id(40035385292692250)
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent5:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36389817495894378)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_read_only_when_type=>'ALWAYS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(39643637120928541)
,p_name=>'Tipos de Declaratoria'
,p_parent_plug_id=>wwv_flow_api.id(40035385292692250)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent5:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'	b.nombre_tipodt ',
'FROM tdt_solicitud a, tipo_declaratoria b ',
'WHERE a.id_tipodt = b.id_tipodt AND a.id_declaratoria = :P209_ID_DECLARATORIA ORDER BY b.nombre_tipodt'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No se encontraron datos'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(250425724942353037)
,p_query_column_id=>1
,p_column_alias=>'NOMBRE_TIPODT'
,p_column_display_sequence=>1
,p_column_heading=>unistr('Tipo Declaraci\00F3n Tur\00EDstica')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(39643898171928543)
,p_name=>'Oficios Relacionados'
,p_parent_plug_id=>wwv_flow_api.id(40035385292692250)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent5:t-Region--scrollBody'
,p_component_template_options=>'[object Object]:[object Object]:[object Object]:[object Object]'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT anotaciones.num_oficio, anotaciones.fecha_oficio, sys.dbms_lob.getlength(anotaciones.oficio) Descargar,',
'anotaciones.tarchivo_oficio, anotaciones.NOMBRE_ARCHIVO, anotaciones.usuario_envia',
'FROM anotaciones',
'WHERE anotaciones.ID_CONTRATO = :P209_ID_CONTRATO'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39643901356928544)
,p_query_column_id=>1
,p_column_alias=>'NUM_OFICIO'
,p_column_display_sequence=>1
,p_column_heading=>'Oficio'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39644061817928545)
,p_query_column_id=>2
,p_column_alias=>'FECHA_OFICIO'
,p_column_display_sequence=>2
,p_column_heading=>'Fecha Oficio'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39644139543928546)
,p_query_column_id=>3
,p_column_alias=>'DESCARGAR'
,p_column_display_sequence=>3
,p_column_heading=>'Descargar'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:ANOTACIONES:OFICIO:NUM_OFICIO::TARCHIVO_OFICIO:NOMBRE_ARCHIVO:::attachment:Abrir:'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39644263728928547)
,p_query_column_id=>4
,p_column_alias=>'TARCHIVO_OFICIO'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39644306837928548)
,p_query_column_id=>5
,p_column_alias=>'NOMBRE_ARCHIVO'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39644442271928549)
,p_query_column_id=>6
,p_column_alias=>'USUARIO_ENVIA'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Quien lo envi\00F3')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(38604833692717378)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40050383172692286)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(36380398837894382)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(40050727019692286)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(40050383172692286)
,p_button_name=>'CERRAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(36468943774894349)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40035651761692256)
,p_name=>'P209_ID_EMPRESA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(39643332213928538)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_source=>'ID_EMPRESA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40036085005692266)
,p_name=>'P209_NOMBRE_SOLICITANTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(39643332213928538)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>'Nombre del Solicitante'
,p_source=>'NOMBRE_SOLICITANTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40036463148692269)
,p_name=>'P209_RAZON_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(39643332213928538)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>unistr('Raz\00F3n Social')
,p_source=>'RAZON_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40036818760692269)
,p_name=>'P209_NOMBRE_COMERCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(39643332213928538)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>'Nombre Comercial'
,p_source=>'NOMBRE_COMERCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40037267039692269)
,p_name=>'P209_TELEFONO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(39643332213928538)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>unistr('Tel\00E9fono')
,p_source=>'TELEFONO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40037645194692269)
,p_name=>'P209_CORREO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(39643332213928538)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>'Correo'
,p_source=>'CORREO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>60
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40038096517692269)
,p_name=>'P209_ID_PROVINCIA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(39643332213928538)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>'Provincia'
,p_source=>'ID_PROVINCIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_PROVINCIAS'
,p_lov=>'select descripcion,id from PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40038485840692270)
,p_name=>'P209_ID_DECLARATORIA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(39643468869928539)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>'ID Declaratoria'
,p_source=>'ID_DECLARATORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40038861231692270)
,p_name=>'P209_FECHADT'
,p_source_data_type=>'DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(39643468869928539)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>'Fecha Registro'
,p_source=>'FechaDT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40039209371692270)
,p_name=>'P209_ANALISTADT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(39643468869928539)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>'Analista Asignado'
,p_source=>'AnalistaDT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40039627388692271)
,p_name=>'P209_FANALISTADT'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(39643468869928539)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>unistr('Fecha asignaci\00F3n al Analista')
,p_source=>'FAnalistaDT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40040077664692271)
,p_name=>'P209_INSPECTORDT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(39643468869928539)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>'Inspector Asignado'
,p_source=>'InspectorDT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40040451282692271)
,p_name=>'P209_FINSPECTORDT'
,p_source_data_type=>'DATE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(39643468869928539)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>unistr('Fecha asignaci\00F3n al Inspector')
,p_source=>'FInspectorDT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40040866097692271)
,p_name=>'P209_ESTADODT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(39643468869928539)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>unistr('Estado del Tr\00E1mite')
,p_source=>'ESTADODT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_ESTADOS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ESTADOS_TRAMITES.ID_ESTADO as ID_ESTADO,',
'    ESTADOS_TRAMITES.DESCRIPCION_ESTADO as DESCRIPCION_ESTADO ',
' from ESTADOS_TRAMITES ESTADOS_TRAMITES'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40041218394692271)
,p_name=>'P209_ID_CONTRATO'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(39643593459928540)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>'ID Contrato'
,p_source=>'ID_CONTRATO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40041695682692272)
,p_name=>'P209_FECHA_REGISTRO'
,p_source_data_type=>'DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(39643593459928540)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>'Fecha Registro'
,p_source=>'FECHA_REGISTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>8
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40042004397692274)
,p_name=>'P209_ID_ANALISTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(39643593459928540)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>'Analista Asignado'
,p_source=>'ID_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40042433196692274)
,p_name=>'P209_FECHA_ASIG_ANALISTA'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(39643593459928540)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>unistr('Fecha asignaci\00F3n al Analista')
,p_source=>'FECHA_ASIG_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40042859136692274)
,p_name=>'P209_ID_INSPECTOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(39643593459928540)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>'Inspector Asignado'
,p_source=>'ID_INSPECTOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40043235573692275)
,p_name=>'P209_FECHA_ASIG_INSPECTOR'
,p_source_data_type=>'DATE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(39643593459928540)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>unistr('Fecha asignaci\00F3n al Inspector')
,p_source=>'FECHA_ASIG_INSPECTOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40043632096692275)
,p_name=>'P209_ESTADOCT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(39643593459928540)
,p_item_source_plug_id=>wwv_flow_api.id(40035385292692250)
,p_prompt=>unistr('Estado del Tr\00E1mite')
,p_source=>'ESTADOCT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_ESTADOS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ESTADOS_TRAMITES.ID_ESTADO as ID_ESTADO,',
'    ESTADOS_TRAMITES.DESCRIPCION_ESTADO as DESCRIPCION_ESTADO ',
' from ESTADOS_TRAMITES ESTADOS_TRAMITES'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(40050812757692286)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(40050727019692286)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(40051690178692292)
,p_event_id=>wwv_flow_api.id(40050812757692286)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(40053976270692296)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(40035385292692250)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Seguimiento de Contratos'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(40054353763692296)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(40053521263692295)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(40035385292692250)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Seguimiento de Contratos'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
