prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>21
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>unistr('Legacy: Detalle An\00E1lisis de Contratos Tur\00EDsticos')
,p_alias=>unistr('FORM-DETALLE-AN\00C1LISIS-CT')
,p_step_title=>unistr('Detalle An\00E1lisis de Contratos Tur\00EDsticos')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20241014103907'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(290453362465557128)
,p_plug_name=>unistr('Datos del Contrato Tur\00EDstico')
,p_region_template_options=>'#DEFAULT#:t-Region--controlsPosEnd:is-collapsed:t-Region--accent1:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36389817495894378)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'CONTRATO_TURISTICO'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(293421309880638502)
,p_name=>'Documentos Relacionados'
,p_parent_plug_id=>wwv_flow_api.id(290453362465557128)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent4:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    id_contrato,',
'    sys.dbms_lob.getlength(estudio_economico) Estudio,',
'    tarchivo_estudio,',
'    NARCHIVO_ESTUDIO,',
'    sys.dbms_lob.getlength(planos_const) Planos,',
'    tarchivo_planos,',
'    NARCHIVO_PLANOS,',
'    sys.dbms_lob.getlength(plan_compras) PlanCompras,',
'    tarchivo_pcompras,',
'    NARCHIVO_PCOMPRAS',
'',
'FROM contrato_turistico WHERE ID_CONTRATO = :P21_ID_CONTRATO'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253263200940334693)
,p_query_column_id=>1
,p_column_alias=>'ID_CONTRATO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253263602230334693)
,p_query_column_id=>2
,p_column_alias=>'ESTUDIO'
,p_column_display_sequence=>2
,p_column_heading=>unistr('Estudio Econ\00F3mico')
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:CONTRATO_TURISTICO:ESTUDIO_ECONOMICO:ID_CONTRATO::TARCHIVO_ESTUDIO:NARCHIVO_ESTUDIO:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253264075618334693)
,p_query_column_id=>3
,p_column_alias=>'TARCHIVO_ESTUDIO'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253264448703334694)
,p_query_column_id=>4
,p_column_alias=>'NARCHIVO_ESTUDIO'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253264860991334694)
,p_query_column_id=>5
,p_column_alias=>'PLANOS'
,p_column_display_sequence=>5
,p_column_heading=>'Planos Constructivos'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:CONTRATO_TURISTICO:PLANOS_CONST:ID_CONTRATO::TARCHIVO_PLANOS:NARCHIVO_PLANOS:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253265211740334694)
,p_query_column_id=>6
,p_column_alias=>'TARCHIVO_PLANOS'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253265614903334694)
,p_query_column_id=>7
,p_column_alias=>'NARCHIVO_PLANOS'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253266097112334695)
,p_query_column_id=>8
,p_column_alias=>'PLANCOMPRAS'
,p_column_display_sequence=>8
,p_column_heading=>'Plan de Compras'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:CONTRATO_TURISTICO:PLAN_COMPRAS:ID_CONTRATO::TARCHIVO_PCOMPRAS:NARCHIVO_PCOMPRAS:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253266482587334695)
,p_query_column_id=>9
,p_column_alias=>'TARCHIVO_PCOMPRAS'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253266843368334695)
,p_query_column_id=>10
,p_column_alias=>'NARCHIVO_PCOMPRAS'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(293535357080302890)
,p_name=>'Oficios Relacionados'
,p_parent_plug_id=>wwv_flow_api.id(290453362465557128)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:is-collapsed:t-Region--accent4:t-Region--scrollBody'
,p_component_template_options=>'t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  ',
'    NUM_OFICIO,  ',
'    sys.dbms_lob.getlength(OFICIO) Descargar,',
'    TARCHIVO_OFICIO,',
'    NOMBRE_ARCHIVO,',
'    USUARIO_ENVIA,',
'    FECHA_OFICIO',
'FROM anotaciones WHERE anotaciones.ID_CONTRATO = :P21_ID_CONTRATO ORDER BY FECHA_OFICIO DESC'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No se encontraron datos'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253267529457334696)
,p_query_column_id=>1
,p_column_alias=>'NUM_OFICIO'
,p_column_display_sequence=>1
,p_column_heading=>unistr('N\00B0 de Oficio')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253267986080334696)
,p_query_column_id=>2
,p_column_alias=>'DESCARGAR'
,p_column_display_sequence=>6
,p_column_heading=>'Descargar'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:ANOTACIONES:OFICIO:NUM_OFICIO::TARCHIVO_OFICIO:NOMBRE_ARCHIVO:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253268315226334697)
,p_query_column_id=>3
,p_column_alias=>'TARCHIVO_OFICIO'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253268710179334697)
,p_query_column_id=>4
,p_column_alias=>'NOMBRE_ARCHIVO'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253269179434334697)
,p_query_column_id=>5
,p_column_alias=>'USUARIO_ENVIA'
,p_column_display_sequence=>4
,p_column_heading=>'Registrado por'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(38604833692717378)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253269579683334697)
,p_query_column_id=>6
,p_column_alias=>'FECHA_OFICIO'
,p_column_display_sequence=>5
,p_column_heading=>'Fecha de Registro'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(544700009165039181)
,p_plug_name=>'Datos de la Empresa'
,p_region_template_options=>'#DEFAULT#:t-Region--controlsPosEnd:is-collapsed:t-Region--accent3:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36389817495894378)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'EMPRESA'
,p_query_where=>'id_empresa = :P21_ID_EMPRESA'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(544775937794275632)
,p_plug_name=>unistr('Datos de la Declaratoria Tur\00EDstica')
,p_region_template_options=>'#DEFAULT#:t-Region--controlsPosEnd:is-collapsed:t-Region--accent5:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36389817495894378)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'DECLARATORIA_TURISTICA'
,p_query_where=>'id_declaratoria = :P21_ID_DECLARATORIA'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(544443399132311365)
,p_name=>unistr('Documentos de la Operaci\00F3n')
,p_parent_plug_id=>wwv_flow_api.id(544775937794275632)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent4:t-Region--scrollBody:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ID_OPERACION_DT,',
'    SI_OPERACION,',
'    sys.dbms_lob.getlength(PERMISO_SALUD) Permiso, ',
'    TARCHIVO_PERMISO, NARCHIVO_PERMISO,',
'    sys.dbms_lob.getlength(CRONOGRAMA) Cronograma, ',
'    TARCHIVO_CRONOGRAMA, NARCHIVO_CRONOGRAMA,',
'    sys.dbms_lob.getlength(PATENTE_MUNICIPAL) Patente, ',
'    TARCHIVO_PATENTE NARCHIVO_PATENTE',
'FROM OPERACION_DT',
'WHERE ID_DECLARATORIA = :P21_ID_DECLARATORIA'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No se encontraron datos'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253240819166174148)
,p_query_column_id=>1
,p_column_alias=>'ID_OPERACION_DT'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253244484130174151)
,p_query_column_id=>2
,p_column_alias=>'SI_OPERACION'
,p_column_display_sequence=>2
,p_column_heading=>unistr('Tipo de Operaci\00F3n')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(39624421094645434)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253241287876174148)
,p_query_column_id=>3
,p_column_alias=>'PERMISO'
,p_column_display_sequence=>4
,p_column_heading=>'Permiso de Salud'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:OPERACION_DT:PERMISO_SALUD:ID_OPERACION_DT::TARCHIVO_PERMISO:NARCHIVO_PERMISO:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253241687366174148)
,p_query_column_id=>4
,p_column_alias=>'TARCHIVO_PERMISO'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253242068657174149)
,p_query_column_id=>5
,p_column_alias=>'NARCHIVO_PERMISO'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253242412690174149)
,p_query_column_id=>6
,p_column_alias=>'CRONOGRAMA'
,p_column_display_sequence=>6
,p_column_heading=>'Cronograma'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:OPERACION_DT:CRONOGRAMA:ID_OPERACION_DT::TARCHIVO_CRONOGRAMA:NARCHIVO_CRONOGRAMA:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253242881788174149)
,p_query_column_id=>7
,p_column_alias=>'TARCHIVO_CRONOGRAMA'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253243274790174149)
,p_query_column_id=>8
,p_column_alias=>'NARCHIVO_CRONOGRAMA'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253243658703174150)
,p_query_column_id=>9
,p_column_alias=>'PATENTE'
,p_column_display_sequence=>9
,p_column_heading=>'Patente Municipal'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:OPERACION_DT:PATENTE_MUNICIPAL:ID_OPERACION_DT::TARCHIVO_PATENTE:NARCHIVO_PATENTE:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253244027302174151)
,p_query_column_id=>10
,p_column_alias=>'NARCHIVO_PATENTE'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(544957049292876848)
,p_name=>unistr('Tipos de Declaratoria Tur\00EDstica')
,p_parent_plug_id=>wwv_flow_api.id(544775937794275632)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:is-collapsed:t-Region--accent4:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'	tdt_solicitud.id_solicitud,',
'	tdt_solicitud.id_catalogo,',
'	tdt_solicitud.id_tipodt,',
'	sys.dbms_lob.getlength(tdt_solicitud.archivo) Descargar,',
'	tdt_solicitud.aprob_cimat, ',
'	tdt_solicitud.flotilla_rent_car,',
'	tdt_solicitud.nombre_archivo,',
'	tdt_solicitud.id_certif_sttt,',
'	tdt_solicitud.zona_indigena,',
'	tdt_solicitud.tarchivo,',
'',
'	(SELECT tipo_declaratoria.nombre_tipodt FROM tipo_declaratoria WHERE tipo_declaratoria.id_tipodt = tdt_solicitud.id_tipodt) as "Tipo",',
unistr('	(SELECT catalogo_categoria.descripcion_categoria FROM catalogo_categoria WHERE catalogo_categoria.id_categoria = tdt_solicitud.id_catalogo) as "Categor\00EDa"'),
'',
'FROM tdt_solicitud WHERE tdt_solicitud.id_declaratoria = :P21_ID_DECLARATORIA'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No se encontraron datos'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253228777382174135)
,p_query_column_id=>1
,p_column_alias=>'ID_SOLICITUD'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253229194224174136)
,p_query_column_id=>2
,p_column_alias=>'ID_CATALOGO'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253229511824174136)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPODT'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253229904238174137)
,p_query_column_id=>4
,p_column_alias=>'DESCARGAR'
,p_column_display_sequence=>4
,p_column_heading=>'Descargar'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:TDT_SOLICITUD:ARCHIVO:ID_SOLICITUD::TARCHIVO:NOMBRE_ARCHIVO:::attachment:Ver:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253230330001174137)
,p_query_column_id=>5
,p_column_alias=>'APROB_CIMAT'
,p_column_display_sequence=>5
,p_column_heading=>'Aprob Cimat'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P21_VALIDACION_CIMAT'
,p_display_when_condition2=>'S'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253230777747174137)
,p_query_column_id=>6
,p_column_alias=>'FLOTILLA_RENT_CAR'
,p_column_display_sequence=>6
,p_column_heading=>'Flotilla Rent Car'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253231155446174138)
,p_query_column_id=>7
,p_column_alias=>'NOMBRE_ARCHIVO'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253231594054174138)
,p_query_column_id=>8
,p_column_alias=>'ID_CERTIF_STTT'
,p_column_display_sequence=>8
,p_column_heading=>'Certificado STTT'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253231965915174138)
,p_query_column_id=>9
,p_column_alias=>'ZONA_INDIGENA'
,p_column_display_sequence=>9
,p_column_heading=>unistr('Zona Ind\00EDgena')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253232303264174138)
,p_query_column_id=>10
,p_column_alias=>'TARCHIVO'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253232787994174139)
,p_query_column_id=>11
,p_column_alias=>'Tipo'
,p_column_display_sequence=>11
,p_column_heading=>'Tipo'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253233134626174139)
,p_query_column_id=>12
,p_column_alias=>unistr('Categor\00EDa')
,p_column_display_sequence=>12
,p_column_heading=>unistr('Categor\00EDa')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(545481786993888201)
,p_name=>'Oficios Relacionados'
,p_parent_plug_id=>wwv_flow_api.id(544775937794275632)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent4:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NUM_OFICIO,',
'       sys.dbms_lob.getlength(OFICIO) Descargar,',
'       TARCHIVO_OFICIO,',
'       USUARIO_ENVIA,',
'       ID_DECLARATORIA,',
'       ID_CONTRATO,',
'       FECHA_OFICIO,',
'       NOMBRE_ARCHIVO',
'FROM ANOTACIONES WHERE id_declaratoria = :P21_ID_DECLARATORIA AND ID_CONTRATO IS NULL ORDER BY FECHA_OFICIO DESC'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No se encontraron datos'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253234222539174140)
,p_query_column_id=>1
,p_column_alias=>'NUM_OFICIO'
,p_column_display_sequence=>1
,p_column_heading=>unistr('N\00B0 de Oficio')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253233849943174140)
,p_query_column_id=>2
,p_column_alias=>'DESCARGAR'
,p_column_display_sequence=>8
,p_column_heading=>'Descargar'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:ANOTACIONES:OFICIO:NUM_OFICIO::TARCHIVO_OFICIO:NOMBRE_ARCHIVO:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253234630302174141)
,p_query_column_id=>3
,p_column_alias=>'TARCHIVO_OFICIO'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253235083652174141)
,p_query_column_id=>4
,p_column_alias=>'USUARIO_ENVIA'
,p_column_display_sequence=>3
,p_column_heading=>'Registrado por'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(38604833692717378)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253235403311174141)
,p_query_column_id=>5
,p_column_alias=>'ID_DECLARATORIA'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253235876368174141)
,p_query_column_id=>6
,p_column_alias=>'ID_CONTRATO'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253236229927174142)
,p_query_column_id=>7
,p_column_alias=>'FECHA_OFICIO'
,p_column_display_sequence=>6
,p_column_heading=>'Fecha de Registro'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253236648838174142)
,p_query_column_id=>8
,p_column_alias=>'NOMBRE_ARCHIVO'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(679276164631722251)
,p_name=>'Documentos Relacionados'
,p_parent_plug_id=>wwv_flow_api.id(544775937794275632)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent4:t-Region--scrollBody:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ID_DECLARATORIA,',
'    sys.dbms_lob.getlength(SOLICITUD) SOLICITUD,',
'    TSOLICITUD,',
'    NSOLICITUD,',
'    sys.dbms_lob.getlength(DESCRIPCION) DESCRIPCION,',
'    TDESCRIPCION,',
'    NDESCRIPCION',
'FROM DECLARATORIA_TURISTICA WHERE ID_DECLARATORIA = :P21_ID_DECLARATORIA;'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No se encontraron datos'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253239345899174146)
,p_query_column_id=>1
,p_column_alias=>'ID_DECLARATORIA'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253239732688174147)
,p_query_column_id=>2
,p_column_alias=>'SOLICITUD'
,p_column_display_sequence=>1
,p_column_heading=>'Solicitud de la Declaratoria'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:DECLARATORIA_TURISTICA:SOLICITUD:ID_DECLARATORIA::TSOLICITUD:NSOLICITUD:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253240156158174147)
,p_query_column_id=>3
,p_column_alias=>'TSOLICITUD'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253237771506174145)
,p_query_column_id=>4
,p_column_alias=>'NSOLICITUD'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253238170662174146)
,p_query_column_id=>5
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>7
,p_column_heading=>unistr('Descripci\00F3n del Proyecto')
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:DECLARATORIA_TURISTICA:DESCRIPCION:ID_DECLARATORIA::TDESCRIPCION:NDESCRIPCION:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253238569103174146)
,p_query_column_id=>6
,p_column_alias=>'TDESCRIPCION'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253238924525174146)
,p_query_column_id=>7
,p_column_alias=>'NDESCRIPCION'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3089506220639963352)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36406847262894371)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3> An\00E1lisis de Contratos Tur\00EDsticos </h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(253197916186068525)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(293535357080302890)
,p_button_name=>'BTN_AGREGAR_OFICIO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--simple:t-Button--iconRight:t-Button--hoverIconPush:t-Button--padTop'
,p_button_template_id=>wwv_flow_api.id(36469031726894349)
,p_button_image_alt=>'Agregar Nuevo Oficio'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::ID_EMPRESA,P10_ID_DECLARATORIA,P10_ID_CONTRATO,P10_CORREO:&P21_ID_EMPRESA.,&P21_ID_DECLARATORIA.,&P21_ID_CONTRATO.,&P21_CORREO.'
,p_icon_css_classes=>'fa-file-plus'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(253255753754174173)
,p_branch_action=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253196080175068506)
,p_name=>'P21_ID_CONTRATO'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_prompt=>'ID del Contrato'
,p_source=>'ID_CONTRATO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253196295309068508)
,p_name=>'P21_FECHA_REGISTRO_CT'
,p_source_data_type=>'DATE'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_prompt=>'Fecha de Registro'
,p_source=>'FECHA_REGISTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253196316821068509)
,p_name=>'P21_FECHA_CADUCIDAD'
,p_source_data_type=>'DATE'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_prompt=>'Fecha de Caducidad'
,p_source=>'FECHA_CADUCIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253196499717068510)
,p_name=>'P21_ESTUDIO_ECONOMICO'
,p_source_data_type=>'BLOB'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_source=>'ESTUDIO_ECONOMICO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253196570948068511)
,p_name=>'P21_PLANOS_CONST'
,p_source_data_type=>'BLOB'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_source=>'PLANOS_CONST'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253196660258068512)
,p_name=>'P21_TARCHIVO_ESTUDIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_source=>'TARCHIVO_ESTUDIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253196782074068513)
,p_name=>'P21_TARCHIVO_PLANOS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_source=>'TARCHIVO_PLANOS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253196841236068514)
,p_name=>'P21_ESTADOCT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_prompt=>unistr('Estado del Tr\00E1mite')
,p_source=>'ESTADOCT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_ESTADOS_TRAMITES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ESTADOS_TRAMITES.ID_ESTADO as ID_ESTADO,',
'    ESTADOS_TRAMITES.DESCRIPCION_ESTADO as DESCRIPCION_ESTADO ',
' from ESTADOS_TRAMITES ESTADOS_TRAMITES'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253196928153068515)
,p_name=>'P21_PLAN_COMPRAS'
,p_source_data_type=>'BLOB'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_source=>'PLAN_COMPRAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253197000516068516)
,p_name=>'P21_TARCHIVO_PCOMPRAS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_source=>'TARCHIVO_PCOMPRAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253197152473068517)
,p_name=>'P21_ID_ANALISTA_CT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_prompt=>'Analista Asignado'
,p_source=>'ID_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre || '' '' || papellido AS nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253197224007068518)
,p_name=>'P21_ID_INSPECTOR_CT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_prompt=>'Inspector Asignado'
,p_source=>'ID_INSPECTOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre || '' '' || papellido AS nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253197399436068519)
,p_name=>'P21_FECHA_ASIG_ANALISTA_CT'
,p_source_data_type=>'DATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_prompt=>unistr('Fecha de Asignaci\00F3n del Analista')
,p_source=>'FECHA_ASIG_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253197422830068520)
,p_name=>'P21_FECHA_ASIG_INSPECTOR_CT'
,p_source_data_type=>'DATE'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_prompt=>unistr('Fecha de Asignaci\00F3n del Inspector')
,p_source=>'FECHA_ASIG_INSPECTOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253197534491068521)
,p_name=>'P21_NARCHIVO_ESTUDIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_source=>'NARCHIVO_ESTUDIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253197662225068522)
,p_name=>'P21_NARCHIVO_PLANOS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_source=>'NARCHIVO_PLANOS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253197702133068523)
,p_name=>'P21_NARCHIVO_PCOMPRAS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_source=>'NARCHIVO_PCOMPRAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253197877082068524)
,p_name=>'P21_ID_USUARIO_CT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(290453362465557128)
,p_item_source_plug_id=>wwv_flow_api.id(290453362465557128)
,p_source=>'ID_USUARIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253214924479174106)
,p_name=>'P21_ID_EMPRESA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(544700009165039181)
,p_item_source_plug_id=>wwv_flow_api.id(544700009165039181)
,p_source=>'ID_EMPRESA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253215302538174110)
,p_name=>'P21_NOMBRE_SOLICITANTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(544700009165039181)
,p_item_source_plug_id=>wwv_flow_api.id(544700009165039181)
,p_prompt=>'Nombre del Solicitante'
,p_source=>'NOMBRE_SOLICITANTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253215718083174112)
,p_name=>'P21_TIPO_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(544700009165039181)
,p_item_source_plug_id=>wwv_flow_api.id(544700009165039181)
,p_prompt=>unistr('Tipo C\00E9dula')
,p_source=>'TIPO_CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253216193727174112)
,p_name=>'P21_NACIONAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(544700009165039181)
,p_item_source_plug_id=>wwv_flow_api.id(544700009165039181)
,p_prompt=>'Nacional/Extranjero'
,p_source=>'NACIONAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253216553510174115)
,p_name=>'P21_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(544700009165039181)
,p_item_source_plug_id=>wwv_flow_api.id(544700009165039181)
,p_prompt=>unistr('N\00B0 de Identificaci\00F3n')
,p_source=>'CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253216913800174115)
,p_name=>'P21_RAZON_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(544700009165039181)
,p_item_source_plug_id=>wwv_flow_api.id(544700009165039181)
,p_prompt=>unistr('Raz\00F3n Social')
,p_source=>'RAZON_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253217341334174115)
,p_name=>'P21_NOMBRE_COMERCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(544700009165039181)
,p_item_source_plug_id=>wwv_flow_api.id(544700009165039181)
,p_prompt=>'Nombre Comercial'
,p_source=>'NOMBRE_COMERCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253217755564174116)
,p_name=>'P21_TELEFONO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(544700009165039181)
,p_item_source_plug_id=>wwv_flow_api.id(544700009165039181)
,p_prompt=>unistr('Tel\00E9fono')
,p_source=>'TELEFONO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253218117562174116)
,p_name=>'P21_CORREO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(544700009165039181)
,p_item_source_plug_id=>wwv_flow_api.id(544700009165039181)
,p_prompt=>'Correo'
,p_source=>'CORREO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>60
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253218521887174116)
,p_name=>'P21_ID_PROVINCIA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(544700009165039181)
,p_item_source_plug_id=>wwv_flow_api.id(544700009165039181)
,p_prompt=>'Provincia'
,p_source=>'ID_PROVINCIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_PROVINCIAS'
,p_lov=>'select descripcion,id from PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253218993919174118)
,p_name=>'P21_ID_CANTON'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(544700009165039181)
,p_item_source_plug_id=>wwv_flow_api.id(544700009165039181)
,p_prompt=>unistr('Cant\00F3n')
,p_source=>'ID_CANTON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_CANTONES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descripcion,id from CANTONES@consulta_ictx',
'--select descripcion, id from CANTONES@consulta_ictx WHERE prov_id = :ID_PROVINCIA'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253219372859174119)
,p_name=>'P21_ID_DISTRITO'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(544700009165039181)
,p_item_source_plug_id=>wwv_flow_api.id(544700009165039181)
,p_prompt=>'Distrito'
,p_source=>'ID_DISTRITO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_DISTRITOS'
,p_lov=>'select descripcion,id from DISTRITOS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253219788962174120)
,p_name=>'P21_DIRECCION_EXACTA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(544700009165039181)
,p_item_source_plug_id=>wwv_flow_api.id(544700009165039181)
,p_prompt=>unistr('Direcci\00F3n Exacta')
,p_source=>'DIRECCION_EXACTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>300
,p_cHeight=>5
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253220148060174120)
,p_name=>'P21_CEDULA_SOLICITANTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(544700009165039181)
,p_item_source_plug_id=>wwv_flow_api.id(544700009165039181)
,p_source=>'CEDULA_SOLICITANTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253221230032174123)
,p_name=>'P21_ID_DECLARATORIA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_prompt=>'ID Declaratoria'
,p_source=>'ID_DECLARATORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253221667541174123)
,p_name=>'P21_ID_USUARIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_source=>'ID_USUARIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253222042648174124)
,p_name=>'P21_CANTIDAD_COLABORADORES'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_prompt=>'Cantidad de Colaboradores'
,p_source=>'CANTIDAD_COLABORADORES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253222487900174124)
,p_name=>'P21_MONEDA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_prompt=>'Moneda'
,p_source=>'MONEDA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253222805946174124)
,p_name=>'P21_MONTO_INVERSION'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_prompt=>unistr('Monto de Inversi\00F3n')
,p_format_mask=>'999G999G999G999G990D00'
,p_source=>'MONTO_INVERSION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253223224196174124)
,p_name=>'P21_ID_ANALISTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_prompt=>'Analista Asignado'
,p_source=>'ID_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre || '' '' || papellido AS nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253223629100174125)
,p_name=>'P21_FECHA_ASIG_ANALISTA'
,p_source_data_type=>'DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_prompt=>unistr('Fecha de Asignaci\00F3n del Analista')
,p_source=>'FECHA_ASIG_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253224055515174126)
,p_name=>'P21_ID_INSPECTOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_prompt=>'Inspector Asignado'
,p_source=>'ID_INSPECTOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre || '' '' || papellido AS nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253224408096174126)
,p_name=>'P21_FECHA_ASIG_INSPECTOR'
,p_source_data_type=>'DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_prompt=>unistr('Fecha de Asignaci\00F3n del Inspector')
,p_source=>'FECHA_ASIG_INSPECTOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253224820049174127)
,p_name=>'P21_FECHA_REGISTRO'
,p_source_data_type=>'DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_prompt=>'Fecha de Registro'
,p_source=>'FECHA_REGISTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253225262999174127)
,p_name=>'P21_ESTADODT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_prompt=>unistr('Estado del Tr\00E1mite')
,p_source=>'ESTADODT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_ESTADOS_TRAMITES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ESTADOS_TRAMITES.ID_ESTADO as ID_ESTADO,',
'    ESTADOS_TRAMITES.DESCRIPCION_ESTADO as DESCRIPCION_ESTADO ',
' from ESTADOS_TRAMITES ESTADOS_TRAMITES'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253225669655174127)
,p_name=>'P21_SOLICITUD'
,p_source_data_type=>'BLOB'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_source=>'SOLICITUD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253226062288174127)
,p_name=>'P21_TSOLICITUD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_source=>'TSOLICITUD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253226476750174130)
,p_name=>'P21_NSOLICITUD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_source=>'NSOLICITUD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253226819460174130)
,p_name=>'P21_DESCRIPCION'
,p_source_data_type=>'BLOB'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_source=>'DESCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253227219619174131)
,p_name=>'P21_TDESCRIPCION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_source=>'TDESCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253227699703174131)
,p_name=>'P21_NDESCRIPCION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(544775937794275632)
,p_item_source_plug_id=>wwv_flow_api.id(544775937794275632)
,p_source=>'NDESCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253244817019174151)
,p_name=>'P21_IDENT_ARC'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(544443399132311365)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(253254503066174171)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Download'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_xml clob; ',
'    l_blob blob; ',
'    l_lang_context integer := DBMS_LOB.DEFAULT_LANG_CTX; ',
'    l_warning integer := DBMS_LOB.WARN_INCONVERTIBLE_CHAR; ',
'    l_dest_offset integer := 1; ',
'    l_source_offset integer := 1; ',
'    l_name varchar2(250);',
'begin',
'    dbms_lob.createtemporary(l_blob, true); ',
'begin ',
'    Select CRONOGRAMA,NARCHIVO_CRONOGRAMA ',
'      into l_blob,l_name ',
'      from OPERACION_DT ',
'     where OPERACION_DT.ID_DECLARATORIA = :P21_ID_DECLARATORIA;',
'    exception when others then RETURN; ',
'    --apex_application.stop_apex_engine; ',
'    --owa_util.http_header_close; ',
'end; ',
'    /*if l_blob is null then return; end if;*/ ',
'    ',
'    htp.init;',
'    -- Set the MIME typebranck',
'    owa_util.mime_header( \''application/octet-stream\'', FALSE,\''UTF-8\'' );',
'    -- Set the name of the file ',
'    htp.p(\''Content-Disposition: attachment; filename=\"\''||l_name||\''\"\'');',
'    owa_util.http_header_close; ',
'    --package that provides an interface to download files (BLOBs and BFILEs)',
'    wpg_docload.download_file( l_blob ); ',
'    --stop further processing and immediately exit',
'    apex_application.stop_apex_engine; ',
'    exception when others then',
'    htp.prn(\''error: \''||sqlerrm); ',
'    apex_application.stop_apex_engine; ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DOWNLOAD'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(253255260459174172)
,p_process_sequence=>60
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Download'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_xml clob; ',
'    l_blob blob; ',
'    l_lang_context integer := DBMS_LOB.DEFAULT_LANG_CTX; ',
'    l_warning integer := DBMS_LOB.WARN_INCONVERTIBLE_CHAR; ',
'    l_dest_offset integer := 1; ',
'    l_source_offset integer := 1; ',
'    l_name varchar2(250);',
'begin',
'    dbms_lob.createtemporary(l_blob, true); ',
'begin ',
'    Select CRONOGRAMA,NARCHIVO_CRONOGRAMA ',
'      into l_blob,l_name ',
'      from OPERACION_DT ',
'     where OPERACION_DT.ID_DECLARATORIA = :P203_ID_DECLARATORIA;',
'    exception when others then RETURN; ',
'    --apex_application.stop_apex_engine; ',
'    --owa_util.http_header_close; ',
'end; ',
'    /*if l_blob is null then return; end if;*/ ',
'    ',
'    htp.init;',
'    -- Set the MIME typebranck',
'    owa_util.mime_header( \''application/octet-stream\'', FALSE,\''UTF-8\'' );',
'    -- Set the name of the file ',
'    htp.p(\''Content-Disposition: attachment; filename=\"\''||l_name||\''\"\'');',
'    owa_util.http_header_close; ',
'    --package that provides an interface to download files (BLOBs and BFILEs)',
'    wpg_docload.download_file( l_blob ); ',
'    --stop further processing and immediately exit',
'    apex_application.stop_apex_engine; ',
'    exception when others then',
'    htp.prn(\''error: \''||sqlerrm); ',
'    apex_application.stop_apex_engine; ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DOWNLOAD'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(253220537264174120)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(544700009165039181)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize: Datos de la Empresa'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(253228044501174132)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(544775937794275632)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize: Datos de la Declaratoria Tur\00EDstica')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(253254873197174171)
,p_process_sequence=>50
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_VALIDA_COLUMNAS_TIPO_DT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'aprCIMAT VARCHAR2(8);',
'',
'CURSOR cursorDT IS ',
'',
'select  tdt_solicitud.aprob_cimat  FROM tdt_solicitud WHERE tdt_solicitud.id_declaratoria = :P203_ID_DECLARATORIA;',
'',
'',
'begin',
'',
'OPEN cursorDT;',
'FETCH cursorDT INTO aprCIMAT;',
'CLOSE cursorDT;',
'',
'  if aprCIMAT is not null',
'  then',
'      :P203_VALIDACION_CIMAT := ''S'';',
'      else',
'      :P203_VALIDACION_CIMAT := ''N'';',
'  end if;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(253195915117068505)
,p_process_sequence=>60
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(290453362465557128)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Form: Detalle An\00E1lisis de Contratos Tur\00EDsticos')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
