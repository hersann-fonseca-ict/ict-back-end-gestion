prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 201
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(36494724852894329)
,p_group_name=>'Administration'
);
wwv_flow_api.component_end;
end;
/
