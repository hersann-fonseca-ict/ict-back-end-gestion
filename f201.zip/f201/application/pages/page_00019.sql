prompt --application/pages/page_00019
begin
--   Manifest
--     PAGE: 00019
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>19
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>unistr('Reporte Transporte Acu\00E1tico')
,p_alias=>unistr('REPORTE-TRANSPORTE-ACU\00C1TICO')
,p_step_title=>unistr('Reporte Transporte Acu\00E1tico')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ADRIANA.RUBIO'
,p_last_upd_yyyymmddhh24miss=>'20230927155514'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15755376206058603)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(36404937346894372)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'CATALOGO_CATEGORIA'
,p_query_where=>'id_tipoDT = ''6'''
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(15755726176058603)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RP,:P20_ID_CATEGORIA:#ID_CATEGORIA##ID_CAT_TRANSP_AC#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ADRIANA.RUBIO'
,p_internal_uid=>15755726176058603
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16196311289030233)
,p_db_column_name=>'ID_CATEGORIA'
,p_display_order=>10
,p_column_identifier=>'D'
,p_column_label=>'Id Categoria'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16196463743030234)
,p_db_column_name=>'DESCRIPCION_CATEGORIA'
,p_display_order=>20
,p_column_identifier=>'E'
,p_column_label=>unistr('Descripci\00F3n Categor\00EDa')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16196555977030235)
,p_db_column_name=>'ESTADO_CATEGORIA'
,p_display_order=>30
,p_column_identifier=>'F'
,p_column_label=>unistr('Estado Categor\00EDa')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_api.id(182620877191192884)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16196610468030236)
,p_db_column_name=>'ID_TIPODT'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>'Id Tipodt'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(15761435523032134)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'157615'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_CATEGORIA:DESCRIPCION_CATEGORIA:ESTADO_CATEGORIA:ID_TIPODT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1378657244984942872)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36406847262894371)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Gesti\00F3n de Transporte Acu\00E1tico</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15758791141058600)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(15755376206058603)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(36468943774894349)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear Nuevo'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:20:P20_ESTADO_CATEGORIA:AC'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(15757731405058600)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(15755376206058603)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15758207541058600)
,p_event_id=>wwv_flow_api.id(15757731405058600)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(15755376206058603)
);
wwv_flow_api.component_end;
end;
/
