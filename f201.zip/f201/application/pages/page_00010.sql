prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>10
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>'Modal: Agregar Oficio '
,p_alias=>'MODAL-AGREGAR-OFICIO'
,p_page_mode=>'MODAL'
,p_step_title=>'Agregar Oficio'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(36494724852894329)
,p_step_template=>wwv_flow_api.id(36356737605894393)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20241017081410'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(291827442754656452)
,p_plug_name=>'Agregar Oficios'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_api.id(36416259815894368)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'ANOTACIONES'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(252664360102580145)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(291827442754656452)
,p_button_name=>'CERRAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--padTop'
,p_button_template_id=>wwv_flow_api.id(36468943774894349)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(253019431591281915)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(291827442754656452)
,p_button_name=>'GUARDAR_DT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--iconRight:t-Button--hoverIconPush:t-Button--padTop'
,p_button_template_id=>wwv_flow_api.id(36469031726894349)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar Oficio'
,p_button_position=>'BELOW_BOX'
,p_button_execute_validations=>'N'
,p_button_condition=>'P10_ID_DECLARATORIA'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-send-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(253199168552068537)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(291827442754656452)
,p_button_name=>'GUARDAR_CT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--iconRight:t-Button--hoverIconPush:t-Button--padTop'
,p_button_template_id=>wwv_flow_api.id(36469031726894349)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar Oficio'
,p_button_position=>'BELOW_BOX'
,p_button_execute_validations=>'N'
,p_button_condition=>'P10_ID_CONTRATO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-send-o'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(253198850135068534)
,p_branch_name=>'Go to Page 8'
,p_branch_action=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::P8_ID_EMPRESA,P8_ID_DECLARATORIA,P8_ID_CONTRATO:&ID_EMPRESA.,&P10_ID_DECLARATORIA.,&P10_ID_CONTRATO.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(253199168552068537)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(256766339748933146)
,p_branch_name=>'Go to Page 8'
,p_branch_action=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::P8_ID_EMPRESA,P8_ID_DECLARATORIA:&ID_EMPRESA.,&P10_ID_DECLARATORIA.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(253019431591281915)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252465044681689837)
,p_name=>'P10_ID_DECLARATORIA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(291827442754656452)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252465158570689838)
,p_name=>'P10_CORREO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(291827442754656452)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252644430572733519)
,p_name=>'P10_NUM_OFICIO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(291827442754656452)
,p_item_source_plug_id=>wwv_flow_api.id(291827442754656452)
,p_prompt=>unistr('N\00FAmero del Oficio')
,p_source=>'NUM_OFICIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(36468051038894349)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252644865260733520)
,p_name=>'P10_OFICIO'
,p_source_data_type=>'BLOB'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(291827442754656452)
,p_item_source_plug_id=>wwv_flow_api.id(291827442754656452)
,p_prompt=>'Archivo del Oficio'
,p_source=>'OFICIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(36468051038894349)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252645291773733520)
,p_name=>'P10_TIPOCORREO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(291827442754656452)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Correo dirigido a'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:A la empresa;E,Interno ICT;I'
,p_field_template=>wwv_flow_api.id(36468051038894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252645670705733520)
,p_name=>'P10_CORREOICT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(291827442754656452)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Correo ICT'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(36468051038894349)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252646059934733521)
,p_name=>'P10_CUERPO_CORREO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(291827442754656452)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Ingrese el texto del mensaje'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>300
,p_cMaxlength=>300
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252646410584733521)
,p_name=>'P10_TARCHIVO_OFICIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(291827442754656452)
,p_item_source_plug_id=>wwv_flow_api.id(291827442754656452)
,p_source=>'TARCHIVO_OFICIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252646830862733521)
,p_name=>'P10_USUARIO_ENVIA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(291827442754656452)
,p_item_source_plug_id=>wwv_flow_api.id(291827442754656452)
,p_source=>'USUARIO_ENVIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252647258944733522)
,p_name=>'P10_ID_CONTRATO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(291827442754656452)
,p_item_source_plug_id=>wwv_flow_api.id(291827442754656452)
,p_source=>'ID_CONTRATO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252647633709733522)
,p_name=>'P10_FECHA_OFICIO'
,p_source_data_type=>'DATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(291827442754656452)
,p_item_source_plug_id=>wwv_flow_api.id(291827442754656452)
,p_source=>'FECHA_OFICIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(253134874019038837)
,p_name=>'ID_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(291827442754656452)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(253499586425183903)
,p_validation_name=>'VALIDAR_NUM_OFICIO_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P10_NUM_OFICIO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar un N\00FAmero de Oficio')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_api.id(252644430572733519)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(253499629883183904)
,p_validation_name=>'VALIDAR_OFICIO_NOT_NULL'
,p_validation_sequence=>20
,p_validation=>'P10_OFICIO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un archivo'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_api.id(252644865260733520)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(253519198676886298)
,p_validation_name=>'VAL_CORREO_FORMAT'
,p_validation_sequence=>30
,p_validation=>'select 1 from dual where not regexp_like (nvl(:P10_CORREOICT,''n/a''), ''^[A-Za-z]+[A-Za-z0-9.]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$'')'
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>unistr('Por favor, ingrese un correo v\00E1lido')
,p_always_execute=>'Y'
,p_validation_condition=>'P10_TIPOCORREO'
,p_validation_condition2=>'I'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_api.id(252645670705733520)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(252661874902548876)
,p_name=>'DAC_CORREO'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10_TIPOCORREO'
,p_condition_element=>'P10_TIPOCORREO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'I'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(252662247824548877)
,p_event_id=>wwv_flow_api.id(252661874902548876)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P10_CORREOICT'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(252662755256548878)
,p_event_id=>wwv_flow_api.id(252661874902548876)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P10_CORREOICT'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(252664589849583901)
,p_name=>'Cancel Dialog'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(252664360102580145)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(252664943626583901)
,p_event_id=>wwv_flow_api.id(252664589849583901)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(253199242151068538)
,p_name=>'DAC_TIPO_OFICIO'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10_ID_CONTRATO'
,p_condition_element=>'P10_ID_CONTRATO'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(253199353955068539)
,p_event_id=>wwv_flow_api.id(253199242151068538)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(253019431591281915)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(253199530523068541)
,p_event_id=>wwv_flow_api.id(253199242151068538)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(253199168552068537)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(253199400235068540)
,p_event_id=>wwv_flow_api.id(253199242151068538)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(253199168552068537)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(253199827978068544)
,p_event_id=>wwv_flow_api.id(253199242151068538)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(253019431591281915)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(252665302052586585)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CERRAR'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(253019608321284134)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_ANOTACIONES_DT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'	vArchivo BLOB;',
'	vTipoArchivo VARCHAR2(255);',
'	vNombreArchivo VARCHAR2(255);',
'	vMensaje_Retorno VARCHAR2(355);',
'	vRetorno boolean;',
'	vEstado NUMBER:= 0;',
'',
'BEGIN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'                 WHERE NAME = :P10_OFICIO;',
'                                        ',
'    PKG_DECLARATORIA.Insertar_Anotacion(:P10_NUM_OFICIO, vArchivo, vTipoArchivo, vNombreArchivo, :APP_USER, ',
'                                        :P10_ID_DECLARATORIA, null, vMensaje_Retorno, vRetorno);',
'                                        ',
'    if :P10_TIPOCORREO = ''E'' then',
unistr('       PKG_CORREOS.ENVIO_CORREO_ADJUN(:P10_CORREO,''Notificaci\00F3n de su tramite de Declaratoria Tur\00EDstica'','),
'                                      :P10_CUERPO_CORREO, :P10_NUM_OFICIO);',
'      ',
'        vEstado := 4;                            ',
'    ',
'    else',
unistr('        PKG_CORREOS.ENVIO_CORREO_ADJUN(:P10_CORREOICT, ''Notificaci\00F3n Declaratoria Tur\00EDstica'','),
'                                       :P10_CUERPO_CORREO, :P10_NUM_OFICIO);',
'     ',
'        vEstado := 5;                            ',
'    end if;',
'    ',
'    PKG_DECLARATORIA.Actualizar_Estado(:P10_ID_DECLARATORIA, vEstado);',
'     ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(253019431591281915)
,p_process_when=>'P10_ID_DECLARATORIA'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>unistr('Oficio agregado con \00E9xito')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(253497321587125396)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_ANOTACIONES_CT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'	vArchivo BLOB;',
'	vTipoArchivo VARCHAR2(255);',
'	vNombreArchivo VARCHAR2(255);',
'	vMensaje_Retorno VARCHAR2(355);',
'	vRetorno boolean;',
'	vEstado NUMBER:= 0;',
'',
'BEGIN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'                 WHERE NAME = :P10_OFICIO;',
'                                        ',
'    PKG_DECLARATORIA.Insertar_Anotacion(:P10_NUM_OFICIO, vArchivo, vTipoArchivo, vNombreArchivo, :APP_USER, ',
'                                        :P10_ID_DECLARATORIA, :P10_ID_CONTRATO, vMensaje_Retorno, vRetorno);',
'                                        ',
'    if :P10_TIPOCORREO = ''E'' then',
unistr('       PKG_CORREOS.ENVIO_CORREO_ADJUN(:P10_CORREO,''Notificaci\00F3n de su tramite de Contrato Tur\00EDstico'','),
'                                      :P10_CUERPO_CORREO, :P10_NUM_OFICIO);',
'      ',
'        vEstado := 4;                            ',
'    ',
'    else',
unistr('        PKG_CORREOS.ENVIO_CORREO_ADJUN(:P10_CORREOICT, ''Notificaci\00F3n Contrato Tur\00EDstico'', '),
'                                       :P10_CUERPO_CORREO, :P10_NUM_OFICIO);',
'     ',
'        vEstado := 5;                            ',
'    end if;',
'    ',
'    PKG_CONTRATO.Actualizar_Estado(:P10_ID_CONTRATO, vEstado);',
'     ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(253199168552068537)
,p_process_success_message=>unistr('Oficio agregado con \00E9xito!')
);
wwv_flow_api.component_end;
end;
/
