prompt --application/pages/page_00202
begin
--   Manifest
--     PAGE: 00202
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>202
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>'ReporteDT_Anotaciones'
,p_alias=>'REPORTEDT-ANOTACIONES'
,p_step_title=>'ReporteDT_Anotaciones'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ADRIANA.RUBIO'
,p_last_upd_yyyymmddhh24miss=>'20230929111820'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(39129625182376228)
,p_name=>unistr('Listado de las Declaratorias Tur\00EDsticas por revisar')
,p_template=>wwv_flow_api.id(36406847262894371)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT empresa.ROWID, empresa.id_empresa , empresa.nombre_solicitante,  empresa.tipo_cedula,empresa.cedula, ',
'  empresa.nacional, empresa.razon_social, empresa.nombre_comercial,',
' empresa.telefono, empresa.correo ,empresa.id_provincia, empresa.id_canton, empresa.id_distrito, empresa.direccion_exacta,',
'',
' declaratoria_turistica.id_declaratoria ,declaratoria_turistica.cantidad_colaboradores ,',
' declaratoria_turistica.moneda, declaratoria_turistica.monto_inversion, ',
' /*',
' sys.dbms_lob.getlength(declaratoria_turistica.SOLICITUD) Solicitud,',
' sys.dbms_lob.getlength(declaratoria_turistica.DESCRIPCION) Descipcion,',
' declaratoria_turistica.TSOLICITUD, declaratoria_turistica.TDESCRIPCION,',
'*/',
'  operacion_dt.id_operacion_dt, operacion_dt.si_operacion, --operacion_dt.permiso_salud, operacion_dt.cronograma, operacion_dt.patente_municipal,',
' sys.dbms_lob.getlength(operacion_dt.permiso_salud) Permiso_Salud,',
' sys.dbms_lob.getlength(operacion_dt.cronograma) Cronograma,',
' sys.dbms_lob.getlength(operacion_dt.patente_municipal) Patente,',
' operacion_dt.tarchivo_permiso, operacion_dt.tarchivo_cronograma,',
' operacion_dt.tarchivo_patente',
'',
'FROM empresa',
'  JOIN declaratoria_turistica ON empresa.id_empresa = declaratoria_turistica.id_empresa ',
'    ',
'  JOIN operacion_dt ON operacion_dt.id_declaratoria = declaratoria_turistica.id_declaratoria',
' ',
'  WHERE declaratoria_turistica.id_analista = PKG_USUARIOS.Consulta_usuario(:APP_USER)',
'     or declaratoria_turistica.ID_INSPECTOR = PKG_USUARIOS.Consulta_usuario(:APP_USER)',
' -- WHERE declaratoria_turistica.id_analista IS NOT NULL',
' '))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Descargar'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39130043190376231)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>1
,p_column_heading=>'Ver detallles'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:203:&SESSION.::&DEBUG.:RP:P203_ROWID:\#ROWID#\'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39130431411376232)
,p_query_column_id=>2
,p_column_alias=>'ID_EMPRESA'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39130850780376233)
,p_query_column_id=>3
,p_column_alias=>'NOMBRE_SOLICITANTE'
,p_column_display_sequence=>4
,p_column_heading=>'Nombre Solicitante'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39131290008376233)
,p_query_column_id=>4
,p_column_alias=>'TIPO_CEDULA'
,p_column_display_sequence=>5
,p_column_heading=>unistr('Tipo C\00E9dula')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39131698941376233)
,p_query_column_id=>5
,p_column_alias=>'CEDULA'
,p_column_display_sequence=>6
,p_column_heading=>unistr('C\00E9dula')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39132086093376233)
,p_query_column_id=>6
,p_column_alias=>'NACIONAL'
,p_column_display_sequence=>7
,p_column_heading=>'Nacional'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39132457740376233)
,p_query_column_id=>7
,p_column_alias=>'RAZON_SOCIAL'
,p_column_display_sequence=>8
,p_column_heading=>unistr('Raz\00F3n Social')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39132815755376234)
,p_query_column_id=>8
,p_column_alias=>'NOMBRE_COMERCIAL'
,p_column_display_sequence=>9
,p_column_heading=>'Nombre Comercial'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39133269472376234)
,p_query_column_id=>9
,p_column_alias=>'TELEFONO'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39133649684376234)
,p_query_column_id=>10
,p_column_alias=>'CORREO'
,p_column_display_sequence=>11
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39134043239376234)
,p_query_column_id=>11
,p_column_alias=>'ID_PROVINCIA'
,p_column_display_sequence=>12
,p_column_heading=>'Provincia'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(19980461641459915)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39134448886376235)
,p_query_column_id=>12
,p_column_alias=>'ID_CANTON'
,p_column_display_sequence=>13
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39134875585376235)
,p_query_column_id=>13
,p_column_alias=>'ID_DISTRITO'
,p_column_display_sequence=>14
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39135262377376235)
,p_query_column_id=>14
,p_column_alias=>'DIRECCION_EXACTA'
,p_column_display_sequence=>15
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39135664380376235)
,p_query_column_id=>15
,p_column_alias=>'ID_DECLARATORIA'
,p_column_display_sequence=>3
,p_column_heading=>'Id Declaratoria'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39136059526376235)
,p_query_column_id=>16
,p_column_alias=>'CANTIDAD_COLABORADORES'
,p_column_display_sequence=>16
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39136491008376236)
,p_query_column_id=>17
,p_column_alias=>'MONEDA'
,p_column_display_sequence=>17
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39136814566376236)
,p_query_column_id=>18
,p_column_alias=>'MONTO_INVERSION'
,p_column_display_sequence=>18
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39137288788376236)
,p_query_column_id=>19
,p_column_alias=>'ID_OPERACION_DT'
,p_column_display_sequence=>19
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39137660969376236)
,p_query_column_id=>20
,p_column_alias=>'SI_OPERACION'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39138020128376237)
,p_query_column_id=>21
,p_column_alias=>'PERMISO_SALUD'
,p_column_display_sequence=>21
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39138458236376237)
,p_query_column_id=>22
,p_column_alias=>'CRONOGRAMA'
,p_column_display_sequence=>22
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39138800100376237)
,p_query_column_id=>23
,p_column_alias=>'PATENTE'
,p_column_display_sequence=>23
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39139285754376237)
,p_query_column_id=>24
,p_column_alias=>'TARCHIVO_PERMISO'
,p_column_display_sequence=>24
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39139602956376237)
,p_query_column_id=>25
,p_column_alias=>'TARCHIVO_CRONOGRAMA'
,p_column_display_sequence=>25
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(39140001903376238)
,p_query_column_id=>26
,p_column_alias=>'TARCHIVO_PATENTE'
,p_column_display_sequence=>26
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2383005756618535615)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36406847262894371)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Listado de las Declaratorias Tur\00EDsticas por revisar</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39141273023376244)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(39129625182376228)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(36468943774894349)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:203:&SESSION.::&DEBUG.:203'
,p_button_condition_type=>'NEVER'
);
wwv_flow_api.component_end;
end;
/
