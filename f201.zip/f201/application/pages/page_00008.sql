prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>unistr('Form: Detalle de la Declaratoria Tur\00EDstica')
,p_alias=>unistr('FORM-DETALLE-AN\00C1LISIS-DT')
,p_step_title=>unistr('Detalle de la Declaratoria Tur\00EDstica')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20240924134223'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(291485920417865096)
,p_plug_name=>'Datos de la Empresa'
,p_region_template_options=>'#DEFAULT#:t-Region--controlsPosEnd:is-collapsed:t-Region--accent3:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36389817495894378)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'EMPRESA'
,p_query_where=>'id_empresa = :P8_ID_EMPRESA'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(291561849047101547)
,p_plug_name=>unistr('Datos de la Declaratoria Tur\00EDstica')
,p_region_template_options=>'#DEFAULT#:t-Region--controlsPosEnd:is-collapsed:t-Region--accent5:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36389817495894378)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'DECLARATORIA_TURISTICA'
,p_query_where=>'id_declaratoria = :P8_ID_DECLARATORIA'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(291229310385137280)
,p_name=>unistr('Documentos de la Operaci\00F3n')
,p_parent_plug_id=>wwv_flow_api.id(291561849047101547)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent4:t-Region--scrollBody:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ID_OPERACION_DT,',
'    SI_OPERACION,',
'    sys.dbms_lob.getlength(PERMISO_SALUD) Permiso, ',
'    TARCHIVO_PERMISO, NARCHIVO_PERMISO,',
'    sys.dbms_lob.getlength(CRONOGRAMA) Cronograma, ',
'    TARCHIVO_CRONOGRAMA, NARCHIVO_CRONOGRAMA,',
'    sys.dbms_lob.getlength(PATENTE_MUNICIPAL) Patente, ',
'    TARCHIVO_PATENTE NARCHIVO_PATENTE',
'FROM OPERACION_DT',
'WHERE ID_DECLARATORIA = :P8_ID_DECLARATORIA'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No se encontraron datos'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252580786178176152)
,p_query_column_id=>1
,p_column_alias=>'ID_OPERACION_DT'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252464709037689834)
,p_query_column_id=>2
,p_column_alias=>'SI_OPERACION'
,p_column_display_sequence=>2
,p_column_heading=>unistr('Tipo de Operaci\00F3n')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(39624421094645434)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252581150017176153)
,p_query_column_id=>3
,p_column_alias=>'PERMISO'
,p_column_display_sequence=>4
,p_column_heading=>'Permiso de Salud'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:OPERACION_DT:PERMISO_SALUD:ID_OPERACION_DT::TARCHIVO_PERMISO:NARCHIVO_PERMISO:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252581598566176153)
,p_query_column_id=>4
,p_column_alias=>'TARCHIVO_PERMISO'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252581940749176153)
,p_query_column_id=>5
,p_column_alias=>'NARCHIVO_PERMISO'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252582382881176153)
,p_query_column_id=>6
,p_column_alias=>'CRONOGRAMA'
,p_column_display_sequence=>6
,p_column_heading=>'Cronograma'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:OPERACION_DT:CRONOGRAMA:ID_OPERACION_DT::TARCHIVO_CRONOGRAMA:NARCHIVO_CRONOGRAMA:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252582789102176154)
,p_query_column_id=>7
,p_column_alias=>'TARCHIVO_CRONOGRAMA'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252583136754176154)
,p_query_column_id=>8
,p_column_alias=>'NARCHIVO_CRONOGRAMA'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252583580146176154)
,p_query_column_id=>9
,p_column_alias=>'PATENTE'
,p_column_display_sequence=>9
,p_column_heading=>'Patente Municipal'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:OPERACION_DT:PATENTE_MUNICIPAL:ID_OPERACION_DT::TARCHIVO_PATENTE:NARCHIVO_PATENTE:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252583984670176155)
,p_query_column_id=>10
,p_column_alias=>'NARCHIVO_PATENTE'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(291742960545702763)
,p_name=>unistr('Tipos de Declaratoria Tur\00EDstica')
,p_parent_plug_id=>wwv_flow_api.id(291561849047101547)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:is-collapsed:t-Region--accent4:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'	tdt_solicitud.id_solicitud,',
'	tdt_solicitud.id_catalogo,',
'	tdt_solicitud.id_tipodt,',
'	sys.dbms_lob.getlength(tdt_solicitud.archivo) Descargar,',
'	tdt_solicitud.aprob_cimat, ',
'	tdt_solicitud.flotilla_rent_car,',
'	tdt_solicitud.nombre_archivo,',
'	tdt_solicitud.id_certif_sttt,',
'	tdt_solicitud.zona_indigena,',
'	tdt_solicitud.tarchivo,',
'',
'	(SELECT tipo_declaratoria.nombre_tipodt FROM tipo_declaratoria WHERE tipo_declaratoria.id_tipodt = tdt_solicitud.id_tipodt) as "Tipo",',
unistr('	(SELECT catalogo_categoria.descripcion_categoria FROM catalogo_categoria WHERE catalogo_categoria.id_categoria = tdt_solicitud.id_catalogo) as "Categor\00EDa"'),
'',
'FROM tdt_solicitud WHERE tdt_solicitud.id_declaratoria = :P8_ID_DECLARATORIA'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No se encontraron datos'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252594199167265461)
,p_query_column_id=>1
,p_column_alias=>'ID_SOLICITUD'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252594511864265462)
,p_query_column_id=>2
,p_column_alias=>'ID_CATALOGO'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252594964407265462)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPODT'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252595394878265462)
,p_query_column_id=>4
,p_column_alias=>'DESCARGAR'
,p_column_display_sequence=>4
,p_column_heading=>'Descargar'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:TDT_SOLICITUD:ARCHIVO:ID_SOLICITUD::TARCHIVO:NOMBRE_ARCHIVO:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252595757230265463)
,p_query_column_id=>5
,p_column_alias=>'APROB_CIMAT'
,p_column_display_sequence=>5
,p_column_heading=>'Aprob Cimat'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P8_VALIDACION_CIMAT'
,p_display_when_condition2=>'S'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252596106774265463)
,p_query_column_id=>6
,p_column_alias=>'FLOTILLA_RENT_CAR'
,p_column_display_sequence=>6
,p_column_heading=>'Flotilla Rent Car'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252596595750265463)
,p_query_column_id=>7
,p_column_alias=>'NOMBRE_ARCHIVO'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252596973082265463)
,p_query_column_id=>8
,p_column_alias=>'ID_CERTIF_STTT'
,p_column_display_sequence=>8
,p_column_heading=>'Certificado STTT'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252597307073265464)
,p_query_column_id=>9
,p_column_alias=>'ZONA_INDIGENA'
,p_column_display_sequence=>9
,p_column_heading=>unistr('Zona Ind\00EDgena')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252597770399265464)
,p_query_column_id=>10
,p_column_alias=>'TARCHIVO'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252598155489265464)
,p_query_column_id=>11
,p_column_alias=>'Tipo'
,p_column_display_sequence=>11
,p_column_heading=>'Tipo'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252598579554265464)
,p_query_column_id=>12
,p_column_alias=>unistr('Categor\00EDa')
,p_column_display_sequence=>12
,p_column_heading=>unistr('Categor\00EDa')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(292267698246714116)
,p_name=>'Oficios Relacionados'
,p_parent_plug_id=>wwv_flow_api.id(291561849047101547)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent4:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NUM_OFICIO,',
'       sys.dbms_lob.getlength(OFICIO) Descargar,',
'       TARCHIVO_OFICIO,',
'       USUARIO_ENVIA,',
'       ID_DECLARATORIA,',
'       ID_CONTRATO,',
'       FECHA_OFICIO,',
'       NOMBRE_ARCHIVO',
'FROM ANOTACIONES WHERE id_declaratoria = :P8_ID_DECLARATORIA AND ID_CONTRATO IS NULL ORDER BY FECHA_OFICIO DESC'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No se encontraron datos'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253133855169038827)
,p_query_column_id=>1
,p_column_alias=>'NUM_OFICIO'
,p_column_display_sequence=>1
,p_column_heading=>unistr('N\00B0 de Oficio')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253134616448038835)
,p_query_column_id=>2
,p_column_alias=>'DESCARGAR'
,p_column_display_sequence=>8
,p_column_heading=>'Descargar'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:ANOTACIONES:OFICIO:NUM_OFICIO::TARCHIVO_OFICIO:NOMBRE_ARCHIVO:::attachment::'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253134039159038829)
,p_query_column_id=>3
,p_column_alias=>'TARCHIVO_OFICIO'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253134180402038830)
,p_query_column_id=>4
,p_column_alias=>'USUARIO_ENVIA'
,p_column_display_sequence=>3
,p_column_heading=>'Registrado por'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(38604833692717378)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253134219084038831)
,p_query_column_id=>5
,p_column_alias=>'ID_DECLARATORIA'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253134369937038832)
,p_query_column_id=>6
,p_column_alias=>'ID_CONTRATO'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253134401827038833)
,p_query_column_id=>7
,p_column_alias=>'FECHA_OFICIO'
,p_column_display_sequence=>6
,p_column_heading=>'Fecha de Registro'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(253134593797038834)
,p_query_column_id=>8
,p_column_alias=>'NOMBRE_ARCHIVO'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(426062075884548166)
,p_name=>'Documentos Relacionados'
,p_parent_plug_id=>wwv_flow_api.id(291561849047101547)
,p_template=>wwv_flow_api.id(36389817495894378)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:t-Region--controlsPosEnd:is-collapsed:t-Region--accent4:t-Region--scrollBody:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ID_DECLARATORIA,',
'    sys.dbms_lob.getlength(SOLICITUD) SOLICITUD,',
'    TSOLICITUD,',
'    NSOLICITUD,',
'    sys.dbms_lob.getlength(DESCRIPCION) DESCRIPCION,',
'    TDESCRIPCION,',
'    NDESCRIPCION',
'FROM DECLARATORIA_TURISTICA WHERE ID_DECLARATORIA = :P8_ID_DECLARATORIA;'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(36433095712894362)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No se encontraron datos'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252575040131087551)
,p_query_column_id=>1
,p_column_alias=>'ID_DECLARATORIA'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252575477741087551)
,p_query_column_id=>2
,p_column_alias=>'SOLICITUD'
,p_column_display_sequence=>1
,p_column_heading=>'Solicitud de la Declaratoria'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:DECLARATORIA_TURISTICA:SOLICITUD:ID_DECLARATORIA::TSOLICITUD:NSOLICITUD:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252573087610087549)
,p_query_column_id=>3
,p_column_alias=>'TSOLICITUD'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252573490679087549)
,p_query_column_id=>4
,p_column_alias=>'NSOLICITUD'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252573827022087550)
,p_query_column_id=>5
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>7
,p_column_heading=>unistr('Descripci\00F3n del Proyecto')
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:DECLARATORIA_TURISTICA:DESCRIPCION:ID_DECLARATORIA::TDESCRIPCION:NDESCRIPCION:::attachment:Descargar:'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252574241563087550)
,p_query_column_id=>6
,p_column_alias=>'TDESCRIPCION'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(252574678966087551)
,p_query_column_id=>7
,p_column_alias=>'NDESCRIPCION'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2836292131892789267)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36406847262894371)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3> An\00E1lisis de Declaratorias Tur\00EDsticas </h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(252464848547689835)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(292267698246714116)
,p_button_name=>'BTN_AGREGAR_OFICIO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--simple:t-Button--iconRight:t-Button--hoverIconPush:t-Button--padTop'
,p_button_template_id=>wwv_flow_api.id(36469031726894349)
,p_button_image_alt=>'Agregar Nuevo Oficio'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::P10_ID_DECLARATORIA,P10_CORREO,ID_EMPRESA:&P8_ID_DECLARATORIA.,&P8_CORREO.,&P8_ID_EMPRESA.'
,p_icon_css_classes=>'fa-file-plus'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(252459445057664323)
,p_branch_action=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252384595296591148)
,p_name=>'P8_ID_EMPRESA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(291485920417865096)
,p_item_source_plug_id=>wwv_flow_api.id(291485920417865096)
,p_source=>'ID_EMPRESA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252384662584591149)
,p_name=>'P8_ID_PROVINCIA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(291485920417865096)
,p_item_source_plug_id=>wwv_flow_api.id(291485920417865096)
,p_prompt=>'Provincia'
,p_source=>'ID_PROVINCIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_PROVINCIAS'
,p_lov=>'select descripcion,id from PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252384755998591150)
,p_name=>'P8_NOMBRE_SOLICITANTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(291485920417865096)
,p_item_source_plug_id=>wwv_flow_api.id(291485920417865096)
,p_prompt=>'Nombre del Solicitante'
,p_source=>'NOMBRE_SOLICITANTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252461480629689801)
,p_name=>'P8_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(291485920417865096)
,p_item_source_plug_id=>wwv_flow_api.id(291485920417865096)
,p_prompt=>unistr('N\00B0 de Identificaci\00F3n')
,p_source=>'CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252461556625689802)
,p_name=>'P8_TELEFONO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(291485920417865096)
,p_item_source_plug_id=>wwv_flow_api.id(291485920417865096)
,p_prompt=>unistr('Tel\00E9fono')
,p_source=>'TELEFONO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252461629374689803)
,p_name=>'P8_CORREO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(291485920417865096)
,p_item_source_plug_id=>wwv_flow_api.id(291485920417865096)
,p_prompt=>'Correo'
,p_source=>'CORREO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>60
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252461781210689804)
,p_name=>'P8_DIRECCION_EXACTA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(291485920417865096)
,p_item_source_plug_id=>wwv_flow_api.id(291485920417865096)
,p_prompt=>unistr('Direcci\00F3n Exacta')
,p_source=>'DIRECCION_EXACTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>300
,p_cHeight=>5
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252461803375689805)
,p_name=>'P8_ID_CANTON'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(291485920417865096)
,p_item_source_plug_id=>wwv_flow_api.id(291485920417865096)
,p_prompt=>unistr('Cant\00F3n')
,p_source=>'ID_CANTON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_CANTONES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descripcion,id from CANTONES@consulta_ictx',
'--select descripcion, id from CANTONES@consulta_ictx WHERE prov_id = :ID_PROVINCIA'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252461927237689806)
,p_name=>'P8_ID_DISTRITO'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(291485920417865096)
,p_item_source_plug_id=>wwv_flow_api.id(291485920417865096)
,p_prompt=>'Distrito'
,p_source=>'ID_DISTRITO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_DISTRITOS'
,p_lov=>'select descripcion,id from DISTRITOS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252462029533689807)
,p_name=>'P8_TIPO_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(291485920417865096)
,p_item_source_plug_id=>wwv_flow_api.id(291485920417865096)
,p_prompt=>unistr('Tipo C\00E9dula')
,p_source=>'TIPO_CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252462111619689808)
,p_name=>'P8_NACIONAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(291485920417865096)
,p_item_source_plug_id=>wwv_flow_api.id(291485920417865096)
,p_prompt=>'Nacional/Extranjero'
,p_source=>'NACIONAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252462297569689809)
,p_name=>'P8_RAZON_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(291485920417865096)
,p_item_source_plug_id=>wwv_flow_api.id(291485920417865096)
,p_prompt=>unistr('Raz\00F3n Social')
,p_source=>'RAZON_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252462353870689810)
,p_name=>'P8_NOMBRE_COMERCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(291485920417865096)
,p_item_source_plug_id=>wwv_flow_api.id(291485920417865096)
,p_prompt=>'Nombre Comercial'
,p_source=>'NOMBRE_COMERCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252462471326689811)
,p_name=>'P8_CEDULA_SOLICITANTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(291485920417865096)
,p_item_source_plug_id=>wwv_flow_api.id(291485920417865096)
,p_source=>'CEDULA_SOLICITANTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252462965275689816)
,p_name=>'P8_ID_DECLARATORIA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_prompt=>'ID Declaratoria'
,p_source=>'ID_DECLARATORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252463012268689817)
,p_name=>'P8_ID_USUARIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_source=>'ID_USUARIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252463295318689819)
,p_name=>'P8_CANTIDAD_COLABORADORES'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_prompt=>'Cantidad de Colaboradores'
,p_source=>'CANTIDAD_COLABORADORES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252463365288689820)
,p_name=>'P8_MONTO_INVERSION'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_prompt=>unistr('Monto de Inversi\00F3n')
,p_format_mask=>'999G999G999G999G990D00'
,p_source=>'MONTO_INVERSION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252463468764689821)
,p_name=>'P8_ESTADODT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_prompt=>unistr('Estado del Tr\00E1mite')
,p_source=>'ESTADODT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_ESTADOS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ESTADOS_TRAMITES.ID_ESTADO as ID_ESTADO,',
'    ESTADOS_TRAMITES.DESCRIPCION_ESTADO as DESCRIPCION_ESTADO ',
' from ESTADOS_TRAMITES ESTADOS_TRAMITES'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252463583663689822)
,p_name=>'P8_MONEDA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_prompt=>'Moneda'
,p_source=>'MONEDA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252463601034689823)
,p_name=>'P8_ID_ANALISTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_prompt=>'Analista Asignado'
,p_source=>'ID_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252463728257689824)
,p_name=>'P8_ID_INSPECTOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_prompt=>'Inspector Asignado'
,p_source=>'ID_INSPECTOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_USUARIOS'
,p_lov=>'select nombre, cedula from usuarios_gestion'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252463887397689825)
,p_name=>'P8_FECHA_REGISTRO'
,p_source_data_type=>'DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_prompt=>'Fecha de Registro'
,p_source=>'FECHA_REGISTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252463907476689826)
,p_name=>'P8_FECHA_ASIG_ANALISTA'
,p_source_data_type=>'DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_prompt=>unistr('Fecha de Asignaci\00F3n del Analista')
,p_source=>'FECHA_ASIG_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252464036018689827)
,p_name=>'P8_FECHA_ASIG_INSPECTOR'
,p_source_data_type=>'DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_prompt=>unistr('Fecha de Asignaci\00F3n del Inspector')
,p_source=>'FECHA_ASIG_INSPECTOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252464161026689828)
,p_name=>'P8_SOLICITUD'
,p_source_data_type=>'BLOB'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_source=>'SOLICITUD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252464297204689829)
,p_name=>'P8_TSOLICITUD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_source=>'TSOLICITUD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252464345653689830)
,p_name=>'P8_NSOLICITUD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_source=>'NSOLICITUD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252464477207689831)
,p_name=>'P8_DESCRIPCION'
,p_source_data_type=>'BLOB'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_source=>'DESCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252464518722689832)
,p_name=>'P8_TDESCRIPCION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_source=>'TDESCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252464623303689833)
,p_name=>'P8_NDESCRIPCION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(291561849047101547)
,p_item_source_plug_id=>wwv_flow_api.id(291561849047101547)
,p_source=>'NDESCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252584346038176157)
,p_name=>'P8_IDENT_ARC'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(291229310385137280)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(252455893194664317)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Download'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_xml clob; ',
'    l_blob blob; ',
'    l_lang_context integer := DBMS_LOB.DEFAULT_LANG_CTX; ',
'    l_warning integer := DBMS_LOB.WARN_INCONVERTIBLE_CHAR; ',
'    l_dest_offset integer := 1; ',
'    l_source_offset integer := 1; ',
'    l_name varchar2(250);',
'begin',
'    dbms_lob.createtemporary(l_blob, true); ',
'begin ',
'    Select CRONOGRAMA,NARCHIVO_CRONOGRAMA ',
'      into l_blob,l_name ',
'      from OPERACION_DT ',
'     where OPERACION_DT.ID_DECLARATORIA = :P8_ID_DECLARATORIA;',
'    exception when others then RETURN; ',
'    --apex_application.stop_apex_engine; ',
'    --owa_util.http_header_close; ',
'end; ',
'    /*if l_blob is null then return; end if;*/ ',
'    ',
'    htp.init;',
'    -- Set the MIME typebranck',
'    owa_util.mime_header( \''application/octet-stream\'', FALSE,\''UTF-8\'' );',
'    -- Set the name of the file ',
'    htp.p(\''Content-Disposition: attachment; filename=\"\''||l_name||\''\"\'');',
'    owa_util.http_header_close; ',
'    --package that provides an interface to download files (BLOBs and BFILEs)',
'    wpg_docload.download_file( l_blob ); ',
'    --stop further processing and immediately exit',
'    apex_application.stop_apex_engine; ',
'    exception when others then',
'    htp.prn(\''error: \''||sqlerrm); ',
'    apex_application.stop_apex_engine; ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DOWNLOAD'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(252603433913359278)
,p_process_sequence=>60
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Download'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    l_xml clob; ',
'    l_blob blob; ',
'    l_lang_context integer := DBMS_LOB.DEFAULT_LANG_CTX; ',
'    l_warning integer := DBMS_LOB.WARN_INCONVERTIBLE_CHAR; ',
'    l_dest_offset integer := 1; ',
'    l_source_offset integer := 1; ',
'    l_name varchar2(250);',
'begin',
'    dbms_lob.createtemporary(l_blob, true); ',
'begin ',
'    Select CRONOGRAMA,NARCHIVO_CRONOGRAMA ',
'      into l_blob,l_name ',
'      from OPERACION_DT ',
'     where OPERACION_DT.ID_DECLARATORIA = :P203_ID_DECLARATORIA;',
'    exception when others then RETURN; ',
'    --apex_application.stop_apex_engine; ',
'    --owa_util.http_header_close; ',
'end; ',
'    /*if l_blob is null then return; end if;*/ ',
'    ',
'    htp.init;',
'    -- Set the MIME typebranck',
'    owa_util.mime_header( \''application/octet-stream\'', FALSE,\''UTF-8\'' );',
'    -- Set the name of the file ',
'    htp.p(\''Content-Disposition: attachment; filename=\"\''||l_name||\''\"\'');',
'    owa_util.http_header_close; ',
'    --package that provides an interface to download files (BLOBs and BFILEs)',
'    wpg_docload.download_file( l_blob ); ',
'    --stop further processing and immediately exit',
'    apex_application.stop_apex_engine; ',
'    exception when others then',
'    htp.prn(\''error: \''||sqlerrm); ',
'    apex_application.stop_apex_engine; ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DOWNLOAD'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(252381651142591119)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(291485920417865096)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize: Datos de la Empresa'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(252462566038689812)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(291561849047101547)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize: Datos de la Declaratoria Tur\00EDstica')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(252603184552357563)
,p_process_sequence=>50
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_VALIDA_COLUMNAS_TIPO_DT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'aprCIMAT VARCHAR2(8);',
'',
'CURSOR cursorDT IS ',
'',
'select  tdt_solicitud.aprob_cimat  FROM tdt_solicitud WHERE tdt_solicitud.id_declaratoria = :P203_ID_DECLARATORIA;',
'',
'',
'begin',
'',
'OPEN cursorDT;',
'FETCH cursorDT INTO aprCIMAT;',
'CLOSE cursorDT;',
'',
'  if aprCIMAT is not null',
'  then',
'      :P203_VALIDACION_CIMAT := ''S'';',
'      else',
'      :P203_VALIDACION_CIMAT := ''N'';',
'  end if;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
