prompt --application/delete_application
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.remove_flow(wwv_flow.g_flow_id);
wwv_flow_api.component_end;
end;
/
